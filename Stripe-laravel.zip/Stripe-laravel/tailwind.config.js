import defaultTheme from 'tailwindcss/defaultTheme';

/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
    './storage/framework/views/*.php',
    './resources/**/*.blade.php',
    './resources/**/*.js',
    './resources/**/*.vue',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Figtree', ...defaultTheme.fontFamily.sans],
      },
      animation: {
        'shine': 'shineMove 2s ease-in-out infinite', // Add the shine animation to the extend section
      },
      keyframes: {
        shineMove: {
          '0%': {
            marginLeft: '-100%',
          },
          '50%': {
            marginLeft: '100%',
          },
          '100%': {
            marginLeft: '-100%',
          },
        },
      },
    },
  },
  plugins: [],
};
