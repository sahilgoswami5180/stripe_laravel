@extends('layouts.app')

@section('title', 'Create Category')

@section('content')

    <div class="container mt-6 px-4">
        <!-- Breadcrumb -->
        <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
                <!-- Home Breadcrumb -->
                <li class="inline-flex items-center">
                    <a href="{{ route('dashboard') }}"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="{{ route('categories.index') }}"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Categories</a>
                    </div>
                </li>

                <!-- Current Page -->
                <li aria-current="page">
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">Create
                            Category</span>
                    </div>
                </li>
            </ol>
        </div>

        <!-- Full-Screen Width Card Container for the Form -->
        <div class="w-full bg-white p-8 rounded-lg shadow-xl">
            <!-- Flex container to align Button and Page Title -->
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-3xl font-semibold text-gray-800 flex items-center">
                    <i class="fas fa-plus-circle mr-2"></i> Add New Category
                </h2>
            </div>

            <!-- Form to Create Category -->
            <form action="{{ route('categories.store') }}" method="POST" class="space-y-6" enctype="multipart/form-data">
                @csrf

                <!-- Category Name -->
                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700">
                        Category Name <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <input type="text" name="name" id="name" value="{{ old('name') }}"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <i class="fas fa-tag absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                    @error('name')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Category Description -->
                <div>
                    <label for="description" class="block text-sm font-medium text-gray-700">
                        Category Description <span class="text-red-500">*</span>
                    </label>
                    <div class="relative">
                        <textarea name="description" id="description" rows="4" maxlength="100" oninput="updateCharCount()"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">{{ old('description') }}</textarea>
                        <i class="fas fa-pencil-alt absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                    <div class="right-18 text-sm text-gray-500 mt-1">
                        <span id="charCount">{{ strlen(old('description')) }}</span> / 100
                    </div>
                    @error('description')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Category Image Upload -->
                <div>
                    <label for="image" class="block text-sm font-medium text-gray-700">
                        Category Image <span class="text-red-500">*</span>
                    </label>
                    <input type="file" name="image" id="image" accept="image/*"
                        class="mt-4 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                        onchange="previewImage()">

                    @error('image')
                        <p class="mt-2 text-sm text-red-500">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Display Image Preview -->
                <div class="mt-4 flex gap-6 col-lg-6">
                    <div id="imagePreviewContainer" class="w-32 h-32 hidden">
                        <img id="imagePreview" src="#" alt="Category Image Preview"
                            class="w-full h-full object-cover rounded-md">
                        <p class="mt-2 text-sm text-gray-500 text-center">New Image</p>
                    </div>
                </div>

                <!-- Submit and Cancel Buttons -->
                <div class="flex justify-end space-x-4 mt-6">
                    <a href="{{ route('categories.index') }}"
                        class="bg-gray-300 text-gray-800 px-6 py-2 rounded hover:bg-gray-400 transition duration-300 flex items-center">
                        <i class="fas fa-times-circle mr-2"></i> Cancel
                    </a>
                    <button type="submit"
                        class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition duration-300 flex items-center">
                        <i class="fas fa-check-circle mr-2"></i>
                        Create Category
                    </button>
                </div>
            </form>

            <!-- Success and Error Toasts -->
            @if (session('success'))
                <div id="successToast"
                    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                    <i class="fas fa-check-circle text-white text-2xl"></i>
                    <span>{{ session('success') }}</span>
                </div>

                <script>
                    setTimeout(() => {
                        document.querySelector('#successToast').style.display = 'none';
                    }, 4000);
                </script>
            @endif

            @if (session('error'))
                <div id="errorToast"
                    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
                    <i class="fas fa-times-circle text-white text-2xl"></i>
                    <span>{{ session('error') }}</span>
                </div>

                <script>
                    setTimeout(() => {
                        document.querySelector('#errorToast').style.display = 'none';
                    }, 4000);
                </script>
            @endif

        </div>
    </div>

    <script>
        // Function to update character count for the description
        function updateCharCount() {
            const textarea = document.getElementById('description');
            const charCount = document.getElementById('charCount');
            charCount.textContent = textarea.value.length; // Update character count
        }

        // Function to preview the image before upload
        function previewImage() {
            const fileInput = document.getElementById('image'); // The file input element
            const imagePreview = document.getElementById('imagePreview'); // Image element for preview
            const imagePreviewContainer = document.getElementById('imagePreviewContainer'); // Container for preview
            const file = fileInput.files[0]; // Get the first selected file

            // Clear the previous image preview
            imagePreview.src = '#'; // Clear previous image preview
            imagePreviewContainer.classList.add('hidden'); // Hide the preview container initially

            // If no file is selected, exit the function
            if (!file) {
                return;
            }

            // Validate file size (max 10MB)
            if (file.size > 10 * 1024 * 1024) { // 10MB in bytes
                alert('Image size must be less than or equal to 10MB.');
                return;
            }

            // Validate file type (only jpeg, png, jpg allowed)
            const validExtensions = ['image/jpeg', 'image/png', 'image/jpg'];
            if (!validExtensions.includes(file.type)) {
                alert('Only image files (jpeg, png, jpg) are allowed.');
                return;
            }

            // If file is valid, create a FileReader to preview the image
            const reader = new FileReader();
            reader.onload = function(event) {
                const result = event.target.result; // Access the file result
                imagePreview.src = result; // Set the preview image source to the loaded file
                imagePreviewContainer.classList.remove('hidden'); // Show the preview container
            };
            reader.readAsDataURL(file); // Read the file as a Data URL for image preview
        }
    </script>

@endsection
