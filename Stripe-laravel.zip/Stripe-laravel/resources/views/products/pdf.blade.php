<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products List</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f7fb;
            color: #333;
        }

        h2 {
            text-align: center;
            font-size: 32px;
            margin-bottom: 30px;
            color: #2c3e50;
            font-weight: bold;
        }

        h3 {
            font-size: 24px;
            margin-top: 30px;
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 10px;
            font-weight: 600;
        }

        .table-header-icon {
            margin-right: 10px;
            vertical-align: middle;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 20px;
        }

        th,
        td {
            padding: 15px;
            text-align: center;
            font-size: 16px;
            color: #555;
            border-bottom: 1px solid #f1f1f1;
        }

        th {
            background-color: #3498db;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
            cursor: pointer;
        }

        /* Small Image size */
        .small-image {
            width: 30px;
            height: 30px;
            object-fit: cover;
            border-radius: 4px;
            margin-right: 5px;
            transition: transform 0.2s ease-in-out;
        }

        .small-image:hover {
            transform: scale(1.1);
        }

        .status-active {
            background-color: #28a745;
            color: white;
            font-weight: bold;
            padding: 5px 12px;
            border-radius: 20px;
        }

        .status-inactive {
            background-color: #e74c3c;
            color: white;
            font-weight: bold;
            padding: 5px 12px;
            border-radius: 20px;
        }

        .price {
            font-weight: bold;
            color: #2ecc71;
            font-size: 14px;
        }

        .price:hover {
            color: #27ae60;
        }

        .table-container {
            max-width: 1200px;
            margin: 0 auto;
            overflow-x: auto;
        }

        /* Scrollable container for images */
        .image-gallery {
            display: flex;
            flex-wrap: nowrap;
            gap: 5px;
            overflow-x: auto;
            justify-content: center;
            max-width: 300px;
            margin: 0 auto;
            padding: 5px 0;
        }

        .image-gallery::-webkit-scrollbar {
            height: 5px;
        }

        .image-gallery::-webkit-scrollbar-thumb {
            background-color: #3498db;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            h2 {
                font-size: 28px;
            }

            th,
            td {
                font-size: 14px;
                padding: 8px;
            }

            .small-image {
                width: 25px;
                height: 25px;
            }

            table {
                margin-top: 10px;
            }
        }

        @media (max-width: 576px) {

            th,
            td {
                font-size: 12px;
                padding: 6px;
            }

            .small-image {
                width: 20px;
                height: 20px;
            }

            .price {
                font-size: 12px;
            }

            h2 {
                font-size: 24px;
            }
        }

        /* New Styles for Category & Subcategory */
        .category-subcategory {
            display: block;
            padding: 5px 10px;
            border-radius: 4px;

            font-weight: bold;

            text-align: center;
            margin-bottom: 5px;
            word-wrap: break-word;
            word-break: break-word;
            max-width: 100%;
        }

        .subcategory {
            /* background-color: #f1c40f;
            color: #fff; */
        }
    </style>
</head>

<body>

    <div class="table-container">
        <h2>Product Inventory</h2>

        <!-- Active Products Section -->
        <h3><i class="fas fa-box-open table-header-icon"></i>Active Products</h3>
        <table id="active-products-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th style="width:140px;">Product Name</th>
                    <th>Category<br> Subcategory</th>
                    <th style="width:80px;">Price</th>
                    <th>Images</th>
                    <th style="width:100px;">Status</th>
                    <th style="width:100px;">Added On</th>
                    <th style="width:100px;">Updated On</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($nonDeletedProducts as $product)
                    <tr>
                        <td>{{ $product->id }}</td>
                        <td>{{ $product->name }}</td>
                        <td>
                            <div class="category-subcategory"
                                style="background-color: {{ getCategoryColor($product->category->id)['background'] }}; color: {{ getCategoryColor($product->category->id)['text'] }};">
                                {{ $product->category->name ?? 'No category' }}
                            </div>

                            <div class="category-subcategory subcategory"
                                style="background-color: {{ getCategoryColor($product->subcategory->id)['background'] }}; color: {{ getCategoryColor($product->subcategory->id)['text'] }};">
                                {{ $product->subcategory->name ?? 'No subcategory' }}
                            </div>

                        </td>
                        <td class="price">${{ number_format($product->price, 2) }}</td>

                        <!-- Display Multiple Images -->
                        <td>
                            @php
                                $images = explode(',', $product->images); // Assuming product images are stored as a comma-separated string
                            @endphp
                            <div class="image-gallery">
                                @foreach ($images as $image)
                                    @if (file_exists(storage_path('app/public/' . $image)))
                                        <img src="{{ asset('storage/' . $image) }}" alt="{{ $product->name }}"
                                            class="small-image">
                                    @else
                                        <img src="{{ asset('images/placeholder.png') }}" alt="Placeholder Image"
                                            class="small-image">
                                    @endif
                                @endforeach
                            </div>
                        </td>

                        <td>
                            <span class="{{ $product->status == 'active' ? 'status-active' : 'status-inactive' }}">
                                <i
                                    class="fas {{ $product->status == 'active' ? 'fa-check-circle' : 'fa-times-circle' }}"></i>
                                {{ ucfirst($product->status) }}
                            </span>
                        </td>
                        <td>{{ $product->created_at->format('M j, Y, g:i a') }}</td>
                        <td>{{ $product->updated_at->format('M j, Y, g:i a') }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <!-- Optional Button to Toggle Deleted Products -->
        <button id="toggle-deleted-btn">Show Deleted Products</button>

        <!-- Display Deleted Products Section only if there are deleted products -->
        <div id="deleted-products-section" style="display:none;">
            <h3><i class="fas fa-trash-alt table-header-icon"></i>Deleted Products</h3>
            <table id="deleted-products-table">
                <thead class="py-2">
                    <tr>
                        <th>#</th>
                        <th style="width:140px;">Product Name</th>
                        <th>Category<br> Subcategory</th>
                        <th style="width:80px;">Price</th>
                        <th>Images</th>
                        <th style="width:100px;">Status</th>
                        <th style="width:100px;">Added On</th>
                        <th style="width:100px;">Updated On</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($deletedProducts as $product)
                        <tr>
                            <td>{{ $product->id }}</td>
                            <td>{{ $product->name }}</td>
                            <td>
                                <div class="category-subcategory"
                                    style="background-color: {{ getCategoryColor($product->category->id)['background'] }}; color: {{ getCategoryColor($product->category->id)['text'] }};">
                                    {{ $product->category->name ?? 'No category' }}
                                </div>

                                <div class="category-subcategory subcategory"
                                    style="background-color: {{ getCategoryColor($product->subcategory->id)['background'] }}; color: {{ getCategoryColor($product->subcategory->id)['text'] }};">
                                    {{ $product->subcategory->name ?? 'No subcategory' }}
                                </div>

                            </td>
                            <td class="price">${{ number_format($product->price, 2) }}</td>

                            <!-- Display Multiple Images -->
                            <td>
                                @php
                                    $images = explode(',', $product->images); // Assuming product images are stored as a comma-separated string
                                @endphp
                                <div class="image-gallery">
                                    @foreach ($images as $image)
                                        @if (file_exists(storage_path('app/public/' . $image)))
                                            <img src="{{ asset('storage/' . $image) }}" alt="{{ $product->name }}"
                                                class="small-image">
                                        @else
                                            <img src="{{ asset('images/placeholder.png') }}" alt="Placeholder Image"
                                                class="small-image">
                                        @endif
                                    @endforeach
                                </div>
                            </td>

                            <td>
                                <span class="{{ $product->status == 'active' ? 'status-active' : 'status-inactive' }}">
                                    <i
                                        class="fas {{ $product->status == 'active' ? 'fa-check-circle' : 'fa-times-circle' }}"></i>
                                    {{ ucfirst($product->status) }}
                                </span>
                            </td>
                            <td>{{ $product->created_at->format('M j, Y, g:i a') }}</td>
                            <td>{{ $product->updated_at->format('M j, Y, g:i a') }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <script>
        // Optional JavaScript to handle dynamic functionalities

        // Function to toggle visibility of the deleted products section
        function toggleDeletedProducts() {
            const deletedSection = document.getElementById('deleted-products-section');
            const toggleButton = document.getElementById('toggle-deleted-btn');

            if (deletedSection.style.display === 'none') {
                deletedSection.style.display = 'block';
                toggleButton.textContent = 'Hide Deleted Products';
            } else {
                deletedSection.style.display = 'none';
                toggleButton.textContent = 'Show Deleted Products';
            }
        }

        // Add event listener for the toggle button
        document.getElementById('toggle-deleted-btn').addEventListener('click', toggleDeletedProducts);
    </script>

    <?php
    // PHP function to get category/subcategory color
    function getCategoryColor($id)
    {
        // Define an array of background and text colors
        $colors = [
            ['background' => '#f39c12', 'text' => '#fff'], // Orange (Dark)
            ['background' => '#f9c74f', 'text' => '#333'], // Orange (Light)
            ['background' => '#e74c3c', 'text' => '#fff'], // Red (Dark)
            ['background' => '#f67280', 'text' => '#333'], // Red (Light)
            ['background' => '#2ecc71', 'text' => '#fff'], // Green (Dark)
            ['background' => '#55d88a', 'text' => '#333'], // Green (Light)
            ['background' => '#3498db', 'text' => '#fff'], // Blue (Dark)
            ['background' => '#a0c4e8', 'text' => '#333'], // Blue (Light)
            ['background' => '#9b59b6', 'text' => '#fff'], // Purple (Dark)
            ['background' => '#be7cb6', 'text' => '#333'], // Purple (Light)
            ['background' => '#1abc9c', 'text' => '#fff'], // Teal (Dark)
            ['background' => '#48c9b0', 'text' => '#333'], // Teal (Light)
            ['background' => '#34495e', 'text' => '#fff'], // Dark Gray
            ['background' => '#7f8c8d', 'text' => '#fff'], // Light Gray
            ['background' => '#16a085', 'text' => '#fff'], // Teal (Darker)
            ['background' => '#1abc9c', 'text' => '#fff'], // Teal (Lighter)
        ];
    
        // Use modulo to loop through the color array
        return $colors[$id % count($colors)];
    }
    
    ?>
</body>

</html>
