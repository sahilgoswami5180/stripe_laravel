@extends('layouts.user')

@section('title', 'E-commerce Shopping | Shop Now')


@section('content')
@if (session('success'))
<div id="toastSuccess"
    class="fixed top-2 left-1/2 transform -translate-x-1/2 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 opacity-0 translate-y-[-20px] transition-all duration-500 ease-out text-center">
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <span>{{ session('success') }}</span>
</div>
@endif

@if (session('error'))
<div id="toastError"
    class="fixed top-2 left-1/2 transform -translate-x-1/2 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 opacity-0 translate-y-[-20px] transition-all duration-500 ease-out">
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <span>{{ session('error') }}</span>
</div>
@endif

<script>
    // Function to show toast notifications
        function showToast(toastId) {
            let toast = document.querySelector(toastId);
            if (toast) {
                setTimeout(() => {
                    toast.classList.remove('opacity-0', 'translate-y-[-20px]');
                    toast.classList.add('opacity-100', 'translate-y-0');
                }, 10);

                setTimeout(() => {
                    toast.classList.remove('opacity-100', 'translate-y-0');
                    toast.classList.add('opacity-0', 'translate-y-[-20px]');
                }, 4000);
            }
        }

        @if (session('success'))
            showToast('#toastSuccess');
        @endif

        @if (session('error'))
            showToast('#toastError');
        @endif
</script>



<div class="flex">
    <!-- Toggle Sidebar Button -->
    <button id="toggleSidebarBtn" class="toggle-sidebar-btn">
        <i class="fas fa-filter"> Filter</i>
    </button>

    <!-- Sidebar Section -->
    <div id="sidebar" class="sidebar">
        <span class="close-btn" id="closeSidebarBtn">
            <i class="fas fa-times"></i>
        </span>
        <h3>Filter Products</h3>

        <form method="GET" action="{{ route('shop.index') }}">
            <!-- Sort by Dropdown -->
            <div class="mb-2">
                <h6 class="filter-title">Sort by</h6>
                <select id="categorySort" name="sort" class="w-full p-2 border border-gray-300 rounded-md">
                    <option value="relevant" {{ request('sort')=='relevant' ? 'selected' : '' }}>Relevant</option>
                    <option value="popular" {{ request('sort')=='popular' ? 'selected' : '' }}>Popular</option>
                    <option value="new" {{ request('sort')=='new' ? 'selected' : '' }}>Newly Added</option>
                </select>
                @error('sort')
                <div class="text-red-500 text-sm mt-1">{{ $message }}</div>
                @enderror
            </div>

            <!-- Category Filter -->
            <div class="mb-2" id="categoriesContainer">
                <h4 class="filter-title">Categories</h4>
                <div id="categoryList">
                    <label class="block mb-2">
                        <input type="checkbox" name="category_id[]" value="all"
                            class="mr-2 p-2 border-gray-300 rounded-sm text-blue-600" {{ in_array('all',
                            request('category_id', [])) ? 'checked' : '' }}>
                        <span class="category-label">All Categories</span>
                    </label>
                    @foreach ($categories as $category)
                    <label class="block mb-2">
                        <input type="checkbox" name="category_id[]" value="{{ $category->id }}"
                            class="mr-2 p-2 border-gray-300 rounded-sm text-blue-600" {{ in_array($category->id,
                        request('category_id', [])) ? 'checked' : '' }}>
                        <span class="category-label">{{ $category->name }}</span>
                    </label>
                    @if ($category->subcategories->isNotEmpty())
                    <div class="ml-4">
                        @foreach ($category->subcategories as $subcategory)
                        <label class="block mb-2">
                            <input type="checkbox" name="subcategory_id[]" value="{{ $subcategory->id }}"
                                class="mr-2 p-2 border-gray-300 rounded-sm text-blue-600" {{ in_array($subcategory->id,
                            request('subcategory_id', [])) ? 'checked' : '' }}>
                            <span class="category-label">{{ $subcategory->name }}</span>
                        </label>
                        @endforeach
                    </div>
                    @endif
                    @endforeach
                </div>
                @error('category_id')
                <div class="text-red-500 text-sm mt-1">{{ $message }}</div>
                @enderror
            </div>

            <!-- Price Range Filter -->
            <div class="mb-2">
                <h4 class="filter-title">Price Range</h4>

                <!-- Range Input -->
                <input type="range" min="0" max="1000000" value="{{ request('price_max', 0) }}" id="priceRange"
                    name="price_max" class="w-full h-2 bg-gray-200 rounded-lg" required>

                <!-- Display Selected Price -->
                <div class="flex justify-between">
                    <span class="price-label">$0</span>
                    <span class="price-label" id="priceValue">${{ request('price_max', 1000000) }}</span>
                    <span class="price-label">$1,000,000</span>
                </div>
                @error('price_max')
                <div class="text-red-500 text-sm mt-1">{{ $message }}</div>
                @enderror
            </div>

            <!-- Submit Button -->
            <button type="submit" class="mt-4 w-full p-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition"
                id="applyFiltersBtn">Apply Filters</button>
        </form>

    </div>



    <!-- Main Content Section -->
    <div id="mainContent" class="content">
        <section id="page-header" style="background-image: url('img/banner/b1.jpg');">
            <h2>#stayhome</h2>
            <p>Save more with coupons & up to 70% off!</p>
        </section>

        <div class="p-4 overflow-x-auto scrollbar-hidden relative left-0">
            <h2 class="text-2xl font-bold text-gray-800 mb-2 text-center">product combos</h2>
            <div class="flex space-x-4 py-4">
                <!-- Previous Button -->
                <button id="prevBtn"
                    class="absolute left-0 top-1/2 transform -translate-y-1/2 px-2 py-1 text-black bg-gray-100 hover:bg-gray-200 bg-opacity-25 hover:bg-opacity-75">
                    <i class="fas fa-chevron-left"></i>
                </button>

                <!-- Combo Cards (First 5 combos) -->
                <div class="flex space-x-4 py-4 overflow-x-auto" id="comboCarousel">
                    @for ($i = 0; $i < 5; $i++) @if (isset($combos[$i])) <div
                        class="card bg-white flex-shrink-0 flex flex-col md:flex-row shadow-xl p-6 rounded-lg"
                        style="width:480px; height:auto; max-width: 30em;">
                        <!-- Image Section -->
                        <div class="w-1/3 p-2">
                            <img src="{{ asset('storage/' . $combos[$i]->image) }}" alt="{{ $combos[$i]->name }}"
                                class="w-full h-auto object-cover rounded-lg shadow-md">
                        </div>

                        <!-- Content Section -->
                        <a href="{{ route('shop.combo_details', $combos[$i]->id) }}"
                            class="w-2/3 flex flex-col justify-between px-4">
                            <div class="w-2/3 flex flex-col justify-between px-4">
                                <h5 class="font-bold text-gray-700 text-2xl">{{ $combos[$i]->name }}</h5>
                                <p class="text-sm text-gray-700">{{ $combos[$i]->description }}</p>
                                <p class="text-sm text-gray-700"><span class="text-green-800">Category:</span>
                                    {{ $combos[$i]->category->name }}</p>
                                <div class="flex justify-between items-center mt-4">
                                    <span class="text-lg font-semibold text-gray-700">${{ $combos[$i]->total_price
                                        }}</span>
                                </div>
                            </div>
                        </a>
                </div>
                @endif
                @endfor
                <div class="card bg-white flex-shrink-0 flex flex-col md:flex-row shadow-xl p-6 rounded-lg"
                    style="width:480px; height:auto; max-width: 30em;">
                    <!-- Image Section -->
                    <div class="w-1/3 p-2">
                        <i class="fa-solid fa-circle-info"></i>
                    </div>
                    <div class="w-2/3 flex flex-col justify-between px-4">
                        <!-- See More Button -->
                        <a href="{{ route('shop.combos') }}"
                            class="flex items-center  text-black px-6 py-3 rounded-md hover:bg-blue-700 transition duration-300">
                            <span class="m-auto text-2xl">See More</span>
                            <i class="fas fa-arrow-right ml-2"></i>
                        </a>
                    </div>
                </div>
            </div>



            <!-- Next Button -->
            <button type="button" id="nextBtn"
                class="absolute right-0 top-1/2 transform -translate-y-1/2 px-2 py-1 text-black bg-gray-100 hover:bg-gray-200 bg-opacity-25 hover:bg-opacity-75">
                <i class="fas fa-chevron-right"></i>
            </button>
        </div>
    </div>

    <section id="banner" class="section-m1">
        <h4>Repair Services</h4>
        <h2>Upto <span>70% Off</span> - All t-Shirts & Accessories</h2>
        <button class="normal">Explore More</button>
    </section>

    <!-- No Products Found -->
    @if ($products->isEmpty())
    <div
        class="max-w-3xl mx-auto bg-white shadow-lg rounded-lg p-6 flex flex-col items-center justify-center text-center">
        <i class="fas fa-search text-6xl text-gray-500 mb-4"></i>
        <h2 class="text-2xl font-semibold text-gray-700 mb-2">No Products Found</h2>
        <p class="text-gray-500">Sorry, we couldn't find any products that match your search.</p>
    </div>

    <div class="mt-6 text-center">
        <a href="{{ route('user.index') }}"
            class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 transition">Go Back to
            Home</a>
    </div>
    @else
    <div class="container mx-auto text-center py-4">
        <h2 class="text-2xl font-bold text-gray-800 mb-2">Featured Products</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            @foreach ($products as $product)
            @php
            $isInWishlist = in_array($product->id, session('wishlist', []));
            $isInCart = isset($cartItems[$product->id]);
            $images = explode(',', $product->images); // Assuming product images are stored as comma-separated strings
            @endphp

            <!-- Product Card -->
            <div class="relative bg-white rounded-lg shadow-lg overflow-hidden group transform transition-all duration-300"
                style="height: 400px; margin-left:-10px;">
                <!-- Wishlist Button -->
                <form
                    action="{{ $isInWishlist ? route('wishlist.remove', $product) : route('wishlist.add', $product) }}"
                    method="POST" class="wishlist-form">
                    @csrf
                    @if ($isInWishlist)
                    @method('DELETE')
                    @endif
                    <button type="submit" class="absolute top-2 right-2 text-red-600 transition z-10"
                        style="border-radius: 60%;">
                        <i class="bx {{ $isInWishlist ? 'bxs-heart text-red-500' : 'bx-heart text-gray-700' }} hover:animate-pulse"
                            style="cursor: pointer; font-size: 24px;"></i>
                    </button>
                </form>

                <!-- Image Carousel Section -->
                <div class="image-carousel-container">
                    @if (is_array($images) && count($images) > 0)
                    <div id="carousel-{{ $product->id }}" class="carousel relative w-full h-56">
                        <div class="carousel-images flex overflow-hidden relative w-full h-full">
                            @foreach ($images as $index => $image)
                            <div class="carousel-item {{ $index == 0 ? 'active' : 'hidden' }} w-full flex-shrink-0">
                                <img src="{{ asset('storage/' . $image) }}" alt="{{ $product->name }}"
                                    class="w-full h-full object-cover rounded-md mx-auto">
                            </div>
                            @endforeach
                        </div>

                        <!-- Carousel Navigation (Next/Previous Buttons) -->
                        @if (count($images) > 1)
                        <button type="button"
                            class="absolute left-0 top-1/2 transform -translate-y-1/2 px-2 py-1 text-black bg-white bg-opacity-50 hover:bg-opacity-75"
                            onclick="moveCarousel('prev', {{ $product->id }})">
                            <i class="fas fa-chevron-left"></i>
                        </button>
                        <button type="button"
                            class="absolute right-0 top-1/2 transform -translate-y-1/2 px-2 py-1 text-black bg-white bg-opacity-50 hover:bg-opacity-75"
                            onclick="moveCarousel('next', {{ $product->id }})">
                            <i class="fas fa-chevron-right"></i>
                        </button>
                        @endif
                    </div>
                    @else
                    <img src="{{ asset('images/placeholder.png') }}" alt="{{ $product->name }}"
                        class="w-full h-56 object-cover rounded-md mx-auto">
                    @endif
                </div>

                <!-- Product Details -->
                <a href="{{ route('shop.product_details', $product->id) }}">
                    <div class="px-4 pb-0 text-left relative" style="margin: 18px -10px;">
                        <span
                            class="text-md font-semibold text-gray-800 mb-2 absolute -top-1 right-0 py-2 pr-4 pl-2 rounded-md transform">
                            <span class="text-xl">₹ </span>{{ $product->price }}
                        </span>
                        <h3 class="text-sm font-semibold text-gray-800 mb-2 w-2/3">
                            {{ Str::limit($product->name, 45, '...') }}</h3>

                        <div class="mt-2 flex items-center gap-2">
                            <div class="flex items-center">
                                @for ($i = 0; $i < 5; $i++) <svg class="h-2 w-2 text-yellow-400" aria-hidden="true"
                                    xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24">
                                    <path
                                        d="M13.8 4.2a2 2 0 0 0-3.6 0L8.4 8.4l-4.6.3a2 2 0 0 0-1.1 3.5l3.5 3-1 4.4c-.5 1.7 1.4 3 2.9 2.1l3.9-2.3 3.9 2.3c1.5 1 3.4-.4 3-2.1l-1-4.4 3.4-3a2 2 0 0 0-1.1-3.5l-4.6-.3-1.8-4.2Z" />
                                    </svg>
                                    @endfor
                            </div>
                            <p class="text-xs font-medium text-gray-900">5.0</p>
                            <p class="text-xs font-medium text-gray-500">(455)</p>
                        </div>

                        <ul class="mt-2 flex items-center gap-4">
                            <li class="flex items-center gap-2">
                                <svg class="h-2 w-2 text-gray-500" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                                    fill="none" viewBox="0 0 24 24">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M13 7h6l2 4m-8-4v8m0-8V6a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v9h2m8 0H9m4 0h2m4 0h2v-4m0 0h-5m3.5 5.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Zm-10 0a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Z" />
                                </svg>
                                <p class="text-xs font-medium text-gray-500">Fast Delivery</p>
                            </li>
                            <li class="flex items-center gap-2">
                                <svg class="h-2 w-2 text-gray-500" xmlns="http://www.w3.org/2000/svg" fill="none"
                                    viewBox="0 0 24 24">
                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                        stroke-width="2" d="M17 7l4 4m0 0l-4 4m4-4H3" />
                                </svg>
                                <p class="text-xs font-medium text-gray-500">Free Shipping</p>
                            </li>
                        </ul>
                        {{-- <div class="flex space-x-2">
                            <div
                                class="text-xs font-semibold text-blue-200 rounded-md uppercase mb-1 text-left bg-gray-500 px-2 py-1 min-w-fit">
                                {{ $product->category->name }}
                            </div>

                            <div
                                class="text-xs font-semibold text-white rounded-md uppercase mb-1 text-left bg-gray-800 w-fit px-4 py-1">
                                {{ $product->subcategory->name }}
                            </div>
                        </div> --}}

                        <!-- Action Buttons (Add to Cart or Quantity Control) -->
                        @if ($isInCart)
                        <div class="mt-0 flex items-center right-0 space-x-4">
                            <!-- Quantity Form -->
                            <form action="{{ route('cart.updateQuantity', $cartItems[$product->id]) }}" method="POST"
                                class="inline-flex items-center space-x-3">
                                @csrf
                                @method('PATCH')
                                <span
                                    class="bg-gray-100 rounded-md text-lg font-semibold text-center inline-block p-3 w-12">
                                    {{ $cartItems[$product->id]['quantity'] }}
                                </span>

                                <div class="flex space-x-2">
                                    <!-- Minus Button -->
                                    <button type="submit" name="quantity"
                                        value="{{ $cartItems[$product->id]['quantity'] - 1 }}"
                                        class="bg-gray-300 text-gray-700 hover:bg-red-600 hover:text-red-200 px-4 py-2 rounded-md transition duration-300 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                                        {{ $cartItems[$product->id]['quantity'] <= 1 ? 'disabled' : '' }}>
                                            <i class="fas fa-minus text-gray-800 "></i>
                                    </button>

                                    <!-- Plus Button -->
                                    <button type="submit" name="quantity"
                                        value="{{ $cartItems[$product->id]['quantity'] + 1 }}"
                                        class="bg-gray-300 text-gray-700 hover:bg-green-600  hover:text-green-100 px-4 py-2 rounded-md transition duration-300 flex items-center justify-center">
                                        <i class="fas fa-plus text-gray-800"></i>
                                    </button>
                                </div>
                            </form>

                            <!-- Delete Button Form -->
                            <form action="{{ route('cart.remove', $cartItems[$product->id]) }}" method="POST"
                                class="inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit"
                                    class="text-white flex items-center py-3 rounded-lg text-red-300 text-center px-4 justify-center space-x-2 hover:text-red-700 w-20 justify-center">
                                    <i class="fas fa-trash-alt text-xl text-gray-400 hover:text-red-600"></i>
                                </button>
                            </form>
                        </div>
                        @else
                        <!-- Add to Cart Button -->
                        <div class="relative bottom-0 right-0 flex space-x-1 mt-6 mx-2 justify-end items-center">
                            <form action="{{ route('cart.add', $product) }}" method="POST" class="w-auto">
                                @csrf
                                <button type="submit"
                                    class="w-full flex items-center justify-end border-2 border-blue-500 text-blue-600 p-2 rounded-xl font-medium hover:bg-blue-800 hover:text-white transition">
                                    <i class="fas fa-shopping-bag text-xs"> ADD TO CART</i>
                                </button>
                            </form>
                        </div>
                        @endif
                    </div>
                </a>
            </div>
            @endforeach
        </div>
    </div>
    @endif
</div>


</div>
<!-- Add JavaScript to handle the carousel navigation -->
<script>
    const prevBtn = document.getElementById('prevBtn');
        const nextBtn = document.getElementById('nextBtn');
        const carousel = document.getElementById('comboCarousel');
        const cardWidth = document.querySelector('.card').offsetWidth + 16; // card width + margin-right

        let scrollPosition = 0;

        // Move to previous combo card
        prevBtn.addEventListener('click', () => {
            if (scrollPosition > 0) {
                scrollPosition -= cardWidth;
                carousel.scrollTo({
                    left: scrollPosition,
                    behavior: 'smooth'
                });
            }
        });

        // Move to next combo card
        nextBtn.addEventListener('click', () => {
            if (scrollPosition < carousel.scrollWidth - carousel.offsetWidth) {
                scrollPosition += cardWidth;
                carousel.scrollTo({
                    left: scrollPosition,
                    behavior: 'smooth'
                });
            }
        });
</script>

<script>
    function moveCarousel(direction, productId) {
            const carousel = document.getElementById(`carousel-${productId}`);
            const items = carousel.querySelectorAll('.carousel-item');
            let activeIndex = -1;

            // Find the currently active item
            items.forEach((item, index) => {
                if (item.classList.contains('active')) {
                    activeIndex = index;
                }
            });

            // Remove the 'active' class from the current item
            items[activeIndex].classList.remove('active');
            items[activeIndex].classList.add('hidden');

            // Determine the new active index based on the direction
            if (direction === 'next') {
                activeIndex = (activeIndex + 1) % items.length; // Wrap around to the first item if we reach the end
            } else if (direction === 'prev') {
                activeIndex = (activeIndex - 1 + items.length) % items
                    .length; // Wrap around to the last item if we reach the beginning
            }

            // Add the 'active' class to the new item
            items[activeIndex].classList.remove('hidden');
            items[activeIndex].classList.add('active');
        }
</script>
<script>
    // ---- Scroll Position Saving and Restoring ----
    // Save scroll position during scrolling
    window.addEventListener('scroll', function() {
        localStorage.setItem('scrollPosition', window.scrollY);
    });

    // Save scroll position before the page is unloaded or reloaded
    window.addEventListener('beforeunload', function() {
        localStorage.setItem('scrollPosition', window.scrollY);
    });

    // Restore scroll position when the page is loaded
    window.addEventListener('load', function() {
        const scrollPosition = localStorage.getItem('scrollPosition');
        if (scrollPosition !== null) {
            window.scrollTo(0, parseInt(scrollPosition)); // Restore the scroll position
            localStorage.removeItem('scrollPosition'); // Remove the position after restoring it
        }
    });

    // ---- Toggle Sidebar Logic ----
    const toggleSidebarBtn = document.getElementById('toggleSidebarBtn');
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('mainContent');
    const closeSidebarBtn = document.getElementById('closeSidebarBtn');

    // Toggle sidebar open/close and shift content
    function toggleSidebar() {
        sidebar.classList.toggle('open');
        content.classList.toggle('shifted');
        toggleSidebarBtn.style.display = sidebar.classList.contains('open') ? 'none' : 'block';
    }

    // Close the sidebar
    function closeSidebar() {
        sidebar.classList.remove('open');
        content.classList.remove('shifted');
        toggleSidebarBtn.style.display = 'block';
    }

    // Attach event listeners
    toggleSidebarBtn.addEventListener('click', toggleSidebar);
    closeSidebarBtn.addEventListener('click', closeSidebar);

    // ---- Filter Button Visibility on Scroll ----
    function handleScroll() {
        if (window.scrollY > 50) {
            toggleSidebarBtn.style.transform = 'translateX(-100%)'; // Hide the button
        } else {
            toggleSidebarBtn.style.transform = 'translateX(0)'; // Show the button
        }
    }

    // Attach the scroll event listener for filter button
    window.addEventListener('scroll', handleScroll);

    // Show the filter button on hover
    toggleSidebarBtn.addEventListener('mouseenter', function() {
        toggleSidebarBtn.style.transform = 'translateX(0)';
    });

    // Keep the filter button visible when not scrolling
    toggleSidebarBtn.addEventListener('mouseleave', function() {
        if (window.scrollY <= 50) {
            toggleSidebarBtn.style.transform = 'translateX(0)';
        }
    });

    // Smooth transition for filter button sliding
    toggleSidebarBtn.style.transition = 'transform 0.3s ease-in-out';

    // ---- Price Range Slider ----
    const priceRange = document.getElementById('priceRange');
    const priceValue = document.getElementById('priceValue');

    // Update the displayed price value
    function updatePriceValue() {
        priceValue.textContent = `$${priceRange.value.toLocaleString()}`;
    }

    // Initial update of price value
    updatePriceValue();

    // Update price value as the range slider moves
    priceRange.addEventListener('input', updatePriceValue);

    // ---- Filter Enabling Logic ----
    // Enable or Disable Apply Filters button based on changes in filters
    const applyFiltersBtn = document.getElementById('applyFiltersBtn');
    document.querySelectorAll('#sidebar input, #sidebar select').forEach(function(input) {
        input.addEventListener('change', function() {
            const anyFilterSelected = document.querySelector('#sidebar input:checked') ||
                document.querySelector('#sidebar select').value !== 'relevant';
            applyFiltersBtn.disabled = !anyFilterSelected;
        });
    });

    // ---- Reset Filters Logic ----
    // Reset filters when Cancel button is clicked
    document.getElementById('cancelFiltersBtn').addEventListener('click', function() {
        const inputs = document.querySelectorAll('#sidebar input, #sidebar select');
        inputs.forEach(input => {
            if (input.type === 'checkbox' || input.type === 'radio') {
                input.checked = false; // Reset checkbox/radio inputs
            } else if (input.tagName === 'SELECT') {
                input.value = 'relevant'; // Reset select inputs to default value
            }
        });

        // Disable "Apply Filters" button when reset
        applyFiltersBtn.disabled = true;
    });
</script>

<style>
    .carousel-item.hidden {
        display: none;
    }

    .carousel-item.active {
        display: block;
    }

    /* Hide scrollbar */
    #comboCarousel::-webkit-scrollbar {
        display: none;
    }

    #comboCarousel {
        scrollbar-width: none;
        /* Firefox */
        -ms-overflow-style: none;
        /* Internet Explorer 10+ */
        overflow-x: auto;
        /* Maintain horizontal scrolling */

    }
</style>

@endsection
