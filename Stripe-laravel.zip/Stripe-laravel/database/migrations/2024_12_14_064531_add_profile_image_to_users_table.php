<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Add profile_image column to the users table
        Schema::table('users', function (Blueprint $table) {
            $table->string('profile_image')->nullable()->after('role'); // Add the profile_image column
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Drop profile_image column from the users table
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('profile_image');
        });
    }
};
