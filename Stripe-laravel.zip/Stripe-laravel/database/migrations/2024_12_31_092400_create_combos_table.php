<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCombosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('combos', function (Blueprint $table) {
            $table->id(); // Primary key
            $table->string('name'); // Combo name
            $table->text('description'); // Combo description
            $table->decimal('total_price', 10, 2); // Total price of the combo
            $table->decimal('disc_price', 10, 2)->nullable(); // Discounted price (optional)
            $table->string('image')->nullable(); // Image URL for the combo (optional)
            $table->unsignedBigInteger('categories_id'); // Foreign key for category
            $table->unsignedBigInteger('subcategories_id'); // Foreign key for subcategory
            $table->timestamps(); // Created_at and updated_at columns
            $table->softDeletes(); // Adds the deleted_at column for soft deletes
        });

        // Adding foreign key constraints
        Schema::table('combos', function (Blueprint $table) {
            $table->foreign('categories_id')->references('id')->on('categories')->onDelete('cascade');
            $table->foreign('subcategories_id')->references('id')->on('subcategories')->onDelete('cascade');
        });

        // Pivot table to link products to combos
        Schema::create('combo_product', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('combo_id'); // Combo foreign key
            $table->unsignedBigInteger('product_id'); // Product foreign key
            $table->timestamps();

            // Adding foreign key constraints for the pivot table
            $table->foreign('combo_id')->references('id')->on('combos')->onDelete('cascade');
            $table->foreign('product_id')->references('id')->on('products')->onDelete('cascade');
            $table->unique(['combo_id', 'product_id']); // Ensures a product is only added once to a combo
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('combo_product');
        Schema::dropIfExists('combos');
    }
}
