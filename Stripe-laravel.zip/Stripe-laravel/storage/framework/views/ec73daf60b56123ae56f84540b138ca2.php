<?php $__env->startSection('content'); ?>
    <div class="container top-0 text-sm -mt-2">
        <!-- Breadcrumb -->
        <div class="flex flex-wrap px-5 py-3 mb-1 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700 mt-0"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
                <li class="inline-flex items-center">
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="<?php echo e(route('products.index')); ?>"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Products</a>
                    </div>
                </li>
            </ol>

            <!-- Action Button: Trashed Categories aligned at the end -->
            <div class="flex items-center justify-end ml-4 mt-2 md:mt-0">
                <a href="<?php echo e(route('deleted-products.index')); ?>"
                    class="bg-yellow-500 text-white px-3 py-2 rounded-full shadow-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition duration-300 text-sm">
                    Trashed Products
                </a>
            </div>
        </div>

        <!-- Button to toggle filter visibility on mobile/tablet -->
        <button id="toggleFilterButton"
            class="lg:hidden bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300 ease-in-out mb-4 w-full">
            <i class="fas fa-filter py-1"></i> Filters
        </button>
        <!-- Button Group (Add New Product, PDF, CSV Download) -->
        <div class="my-4 flex justify-end gap-4 flex-wrap">


            <!-- PDF Download Button -->
            <a href="<?php echo e(route('products.export.pdf')); ?>"
                class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-400 transition duration-300 ease-in-out flex items-center text-sm justify-center">
                <i class="fas fa-file-pdf py-1 mr-1"></i>
                <span class="hidden sm:inline-flex"> Download PDF</span>
            </a>

            <!-- CSV Download Button -->
            <a href="<?php echo e(route('products.export.csv')); ?>"
                class="bg-yellow-500 text-white px-4 py-2 rounded-lg hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition duration-300 ease-in-out flex items-center text-sm justify-center">
                <i class="fas fa-file-csv py-1 mr-1"></i>
                <span class="hidden sm:inline-flex"> Download CSV</span>
            </a>
            <!-- Add New Product Button -->
            <a href="<?php echo e(route('products.create')); ?>"
                class="bg-indigo-700 text-white px-4 py-2 rounded-full hover:bg-indigo-800 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition duration-300 ease-in-out flex items-center text-sm justify-center">
                <i class="fas fa-plus-circle mr-2"></i>
                <span class="">Add New Product</span>
            </a>
        </div>
        <!-- Filter Bar (Initially Hidden on Small Devices, Visible on Desktop) -->
        <div id="filterBar"
            class="lg:flex hidden flex-wrap justify-between gap-4 mb-4 bg-gradient-to-r from-indigo-50 to-indigo-100 p-4 rounded-xl shadow-xl">
            <!-- Filter Inputs Form -->
            <form action="<?php echo e(route('products.index')); ?>" method="GET" class="flex flex-wrap gap-4 w-full items-center">

                <!-- Search Input -->
                <input type="text" name="search" placeholder="Search by product name..."
                    class="px-4 py-2 text-sm rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300 ease-in-out w-full sm:w-64 shadow-md hover:shadow-lg">

                <!-- Category Select -->
                <select name="category_id"
                    class="p-2 text-sm rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white shadow-md hover:border-blue-400 transition duration-300 ease-in-out w-full sm:w-28">
                    <option value="" class="text-gray-500" disabled selected>Category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" class="text-gray-700"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <!-- Subcategory Select -->
                <select name="subcategory_id"
                    class="px-4 py-2 text-sm rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-white shadow-md hover:border-blue-400 transition duration-300 ease-in-out w-full sm:w-36">
                    <option value="" class="text-gray-500" disabled selected>Subcategory</option>
                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subcategory->id); ?>" class="text-gray-700"><?php echo e($subcategory->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <!-- Status Select -->
                <select name="status"
                    class="px-4 py-2 text-sm rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 bg-white shadow-md hover:border-green-400 transition duration-300 ease-in-out w-full sm:w-28">
                    <option value="" class="text-gray-500" disabled selected>Status</option>
                    <option value="active" class="text-green-600">Active</option>
                    <option value="inactive" class="text-red-600">Inactive</option>
                </select>

                <!-- Apply Filters Button -->
                <button type="submit"
                    class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300 ease-in-out w-full sm:w-auto">
                    <i class="fas fa-filter py-1"></i> Apply Filters
                </button>

                <!-- Reset Button -->
                <a href="<?php echo e(route('products.index')); ?>"
                    class="bg-gray-300 text-black text-center px-4 py-2 rounded-lg hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-400 transition duration-300 ease-in-out w-full sm:w-auto">
                    <i class="fas fa-undo py-1"></i> Reset
                </a>
            </form>
        </div>


        <!-- Display Product Count -->
        <div class="lg:hidden justify-start bg-gray-200 text-gray-800 w-fit px-4 py-2 rounded-md mt-4">
            <span>
                Showing <?php echo e($products->firstItem()); ?> to <?php echo e($products->lastItem()); ?> of <?php echo e($products->total()); ?>

                products
            </span>
        </div>
        <!-- Table -->
        <div class="overflow-x-auto bg-white rounded-lg shadow-xl mt-1">

            <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
                <thead class="bg-gray-100 text-gray-600">
                    <tr>
                        <th class="px-4 py-3 text-center text-md font-bold">#</th>
                        <th class="px-4 py-3 text-center text-md font-bold">Product Name</th>
                        <th class="px-4 py-3 text-center text-md font-bold">Category</th>
                        <th class="px-4 py-3 text-center text-md font-bold">Subcategory</th>
                        <th class="px-4 py-3 text-center text-md font-bold">Price</th>
                        <th class="px-4 py-3 text-center text-md font-bold">Status</th>
                        <th class="px-4 py-3 text-center text-md font-bold">Image</th>
                        <th class="px-4 py-3 text-center text-md font-bold">Actions</th>
                        <th class="px-4 py-3 text-center text-md font-bold" style="width:115px;">Qr-Code</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr
                            class="hover:bg-gray-50 transition-colors text-center duration-200
                    <?php if($index % 2 === 0): ?> bg-gray-50 <?php else: ?> bg-gray-100 <?php endif; ?>">
                            <td class="px-4 py-4 text-md text-gray-800"><?php echo e($product->id); ?></td>
                            <td class="px-4 py-4 text-sm text-gray-800 uppercase font-semibold"><?php echo e($product->name); ?></td>
                            <td class="px-4 py-4 text-md text-gray-800"><?php echo e($product->category->name ?? 'No category'); ?>

                            </td>
                            <td class="px-4 py-4 text-md text-gray-800">
                                <?php echo e($product->subcategory->name ?? 'No subcategory'); ?></td>
                            <td class="px-4 py-4 text-md text-gray-800">₹<?php echo e(number_format($product->price, 2)); ?></td>
                            <td class="px-4 py-4 text-md text-center">
                                <button
                                    onclick="openStatusConfirmationModal(<?php echo e($product->id); ?>, '<?php echo e($product->status); ?>')"
                                    class="px-4 py-2 rounded-md transition duration-300 toast-btn
                            <?php echo e($product->status == 'active' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'); ?>">
                                    <?php echo e($product->status == 'active' ? 'Active' : 'Inactive'); ?>

                                </button>
                            </td>
                            <td class="px-4 py-4 text-md text-center">
                                <!-- Image Carousel Section -->
                                <div class="image-carousel-container">
                                    <?php
                                        $images = explode(',', $product->images); // Convert the comma-separated string into an array
                                    ?>

                                    <?php if(is_array($images) && count($images) > 0): ?>
                                        <!-- Carousel Wrapper -->
                                        <div id="carousel-<?php echo e($product->id); ?>" class="carousel relative">
                                            <!-- Carousel Images -->
                                            <div class="carousel-images">
                                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                                        <img src="<?php echo e(asset('storage/' . $image)); ?>"
                                                            alt="<?php echo e($product->name); ?>"
                                                            class="w-35 h-20 object-cover rounded-md mx-auto cursor-pointer">
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('images/placeholder.png')); ?>" alt="<?php echo e($product->name); ?>"
                                            class="w-35 h-20 object-cover rounded-md mx-auto cursor-pointer">
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-2 py-4 text-md text-center">
                                <div class="flex justify-center space-x-2">
                                    <a href="<?php echo e(route('products.show', $product)); ?>"
                                        class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-300 flex items-center space-x-2">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('products.edit', $product)); ?>"
                                        class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300 flex items-center space-x-2">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button type="button"
                                        class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 flex items-center space-x-2"
                                        onclick="openDeleteModal(<?php echo e($product->id); ?>)">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </div>
                            </td>
                            <td class="px-2 py-4 text-md text-center">
                                <button id="qrButton-<?php echo e($product->id); ?>"
                                    onclick="toggleQRCodePreview(<?php echo e($product->id); ?>, '<?php echo e($product->name); ?>', '<?php echo e($product->description); ?>', '<?php echo e(number_format($product->price, 2)); ?>', '<?php echo e(ucfirst($product->status)); ?>', '<?php echo e($product->category->name ?? 'No category'); ?>')"
                                    class="bg-indigo-500 text-white px-4 py-2 m-auto rounded hover:bg-indigo-600 transition duration-300 flex items-center space-x-2">
                                    <i id="qrIcon-<?php echo e($product->id); ?>" class="fas fa-qrcode"></i>
                                </button>

                                <div id="qrCodeContainer-<?php echo e($product->id); ?>" class="mt-4 hidden">
                                    <img id="qrCode-<?php echo e($product->id); ?>" src="" alt="QR Code" class="mx-auto">
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-4">
            <div class="flex items-center justify-between">
                <!-- Previous Button (Visible only on Desktop) -->
                <a href="<?php echo e($products->previousPageUrl()); ?>"
                    class="hidden px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 focus:outline-none">
                    <i class="fas fa-chevron-left"></i> Previous
                </a>




                <div class="mt-4 lg:flex lg:justify-end text-gray-800 text-center w-full rounded-lg">
                    <?php echo e($products->links()); ?>

                </div>

                <a href="<?php echo e($products->nextPageUrl()); ?>"
                    class="hidden px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 focus:outline-none">
                    Next <i class="fas fa-chevron-right"></i>
                </a>
            </div>
        </div>


        <?php if($products->isEmpty()): ?>
            <div class="mt-8 text-center text-gray-500">
                <p>No products found. Create a new product to get started!</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Status Confirmation Modal -->
    <div id="statusModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-xl">
            <div class="flex items-center mb-4">
                <i class="fas fa-exclamation-circle text-yellow-600 text-3xl mr-4"></i>
                <h3 class="text-xl font-semibold text-gray-800">Are you sure you want to change the status?</h3>
            </div>
            <p class="text-gray-700 mb-4 text-center">
                Changing the status will affect the current item’s state in the system. The changes are not reversible.
            </p>
            <div class="flex justify-end gap-4 mt-6">
                <button onclick="closeStatusModal()"
                    class="flex items-center justify-center px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition duration-300">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </button>
                <form id="statusForm" method="POST" class="inline-block">
                    <?php echo csrf_field(); ?>
                    <button type="submit"
                        class="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-300">
                        <i class="fas fa-check-circle mr-2"></i> Confirm
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
        <div class="bg-white p-6 rounded-lg shadow-lg w-full max-w-xl">
            <div class="flex items-center mb-4">
                <i class="fas fa-archive text-yellow-600 text-3xl mr-4"></i>
                <h3 class="text-xl font-semibold text-gray-800">Are you sure you want to archive this product?</h3>
            </div>
            <p class="text-gray-700 mb-4 text-center">
                Archiving this product will hide it from the active list but it will not be permanently deleted. You can
                restore it later if needed.
            </p>
            <div class="flex justify-end gap-4 mt-6">
                <button onclick="closeDeleteModal()"
                    class="flex items-center justify-center px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition duration-300">
                    <i class="fas fa-times-circle mr-2"></i> Cancel
                </button>
                <form id="deleteForm" method="POST" class="inline-block">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit"
                        class="flex items-center justify-center px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 transition duration-300">
                        <i class="fas fa-archive mr-2"></i> Archive
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('toggleFilterButton').addEventListener('click', function() {
            var filterBar = document.getElementById('filterBar');
            if (filterBar.classList.contains('hidden')) {
                filterBar.classList.remove('hidden');
            } else {
                filterBar.classList.add('hidden');
            }
        });
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Loop through each carousel and add auto-play functionality
            document.querySelectorAll('.carousel').forEach(function(carousel) {
                const items = carousel.querySelectorAll('.carousel-item');
                const totalItems = items.length;
                let currentIndex = 0;

                // Function to show the next image
                function showNext() {
                    // Increment the index and use modulo to ensure it wraps around
                    currentIndex = (currentIndex + 1) % totalItems;
                    updateCarousel();
                }

                // Function to update the carousel (move to the next image)
                function updateCarousel() {
                    const offset = -currentIndex * 100; // Slide by 100% width of each image
                    carousel.querySelector('.carousel-images').style.transition =
                        'transform 0.5s ease'; // Smooth transition
                    carousel.querySelector('.carousel-images').style.transform = `translateX(${offset}%)`;
                }

                // Set interval to auto-play every 3 seconds
                setInterval(showNext, 3000); // Change image every 3 seconds

                // Optional: Handle infinite looping (reset carousel to first image smoothly)
                // This can be used to reset the carousel after a transition completes.
                carousel.querySelector('.carousel-images').addEventListener('transitionend', function() {
                    // Check if the last image has been reached and reset
                    if (currentIndex === 0) {
                        carousel.querySelector('.carousel-images').style.transition =
                            'none'; // Disable transition for reset
                        updateCarousel(); // Immediately jump to first image
                        // Force reflow (important for smooth reset)
                        carousel.querySelector('.carousel-images').offsetHeight; // Trigger reflow
                        carousel.querySelector('.carousel-images').style.transition =
                            'transform 0.5s ease'; // Re-enable transition
                    }
                });
            });
        });
    </script>



    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.0/build/qrcode.min.js"></script>
    <script>
        function openStatusConfirmationModal(productId, currentStatus) {
            statusForm.action = `/products/${productId}/change-status`;
            let actionText = currentStatus === 'active' ? 'Inactivate' : 'Activate';
            statusForm.innerHTML = `
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Confirm to ${actionText}</button>
                    `;
            statusModal.classList.remove('hidden');
        }

        function closeStatusModal() {
            statusModal.classList.add('hidden');
        }
        // Function to open delete modal
        function openDeleteModal(productId) {
            const deleteForm = document.getElementById('deleteForm');
            deleteForm.action = `/products/${productId}/delete`;
            document.getElementById('deleteModal').classList.remove('hidden');
        }

        // Function to close delete modal
        function closeDeleteModal() {
            document.getElementById('deleteModal').classList.add('hidden');
        }

        // Function to toggle QR code preview
        function toggleQRCodePreview(productId, name, description, price, status, category) {
            const qrCodeContainer = document.getElementById(`qrCodeContainer-${productId}`);
            const qrCodeImage = document.getElementById(`qrCode-${productId}`);
            const qrIcon = document.getElementById(`qrIcon-${productId}`);

            if (qrCodeContainer.classList.contains('hidden')) {
                qrCodeContainer.classList.remove('hidden');
                qrIcon.classList.remove('fa-qrcode');
                qrIcon.classList.add('fa-times-circle');

                const qrData =
                    `Name: ${name}\nDescription: ${description}\nPrice: $${price}\nStatus: ${status}\nCategory: ${category}`;

                QRCode.toDataURL(qrData, {
                    width: 128,
                    height: 128
                }, function(err, url) {
                    if (err) {
                        console.error("QR Code generation error:", err);
                        return;
                    }
                    qrCodeImage.src = url;
                });
            } else {
                qrCodeContainer.classList.add('hidden');
                qrIcon.classList.remove('fa-times-circle');
                qrIcon.classList.add('fa-qrcode');
            }
        }
    </script>

    <?php if(session('success')): ?>
        <div id="successToast"
            class="fixed top-16 right-0 z-50 bg-green-500 text-white px-4 py-3 rounded-md shadow-md flex items-center space-x-3">
            <!-- Success Icon -->
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <!-- Success Message -->
            <span><?php echo e(session('success')); ?></span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>

    <!-- Error Toast -->
    <?php if(session('error')): ?>
        <div id="errorToast"
            class="fixed top-16 right-10 z-50 bg-red-500 text-white px-4 py-3 rounded-md shadow-md flex items-center space-x-3">
            <!-- Error Icon -->
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <!-- Error Message -->
            <span><?php echo e(session('error')); ?></span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>

    <style>
        .carousel {
            position: relative;
            width: 100%;
            max-width: 300px;
            /* You can adjust the width based on your needs */
            margin: 0 auto;
            overflow: hidden;
        }

        .carousel-images {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }

        .carousel-item {
            min-width: 100%;
            display: flex;
            justify-content: center;
        }

        .carousel-item img {
            object-fit: cover;
            width: 100%;
            height: auto;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth/resources/views/products/index.blade.php ENDPATH**/ ?>