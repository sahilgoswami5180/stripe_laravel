<?php $__env->startComponent('mail::message'); ?>
# Order Confirmation

Thank you for your order! Your order has been placed successfully.

**Order ID:** <?php echo e($order->id); ?>

**Total Amount:** $<?php echo e($order->total); ?>

**Payment Method:** Cash on Delivery

We will contact you shortly to arrange for delivery.

Thanks,
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth (copy)/resources/views/emails/orders/placed.blade.php ENDPATH**/ ?>