<?php $__env->startSection('title', 'Payment Successful'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('success')): ?>
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Success Icon -->
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <!-- Success Message -->
    <span><?php echo e(session('success')); ?></span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#successToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>

<!-- Error Toast -->
<?php if(session('error')): ?>
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
    <!-- Error Icon -->
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <!-- Error Message -->
    <span><?php echo e(session('error')); ?></span>
</div>

<script>
    setTimeout(() => {
        document.querySelector('#errorToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>
<section class="py-12">
    <div class="container mx-auto text-center">
        <h1 class="text-4xl font-bold text-green-500 mb-4">Payment Successful!</h1>
        <p class="text-lg">Your payment has been processed successfully. Thank you for your purchase!</p>
        <a href="<?php echo e(route('dashboard')); ?>" class="text-blue-500 mt-4 inline-block">Go to Dashboard</a>
    </div>
</section>


<script type="text/javascript">
    setTimeout(function(){
        window.location.href = "<?php echo e(route('user.index')); ?>"; // Redirect to the user index page
    }, 5000);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth (copy)/resources/views/user/paysuccess.blade.php ENDPATH**/ ?>