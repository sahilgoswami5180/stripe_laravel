<?php $__env->startSection('title', 'Combo Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto mt-2 min-h-screen flex flex-col">
        <!-- Breadcrumb -->
        <div class="flex px-5 py-4 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700 mb-4"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
                <!-- Home Breadcrumb -->
                <li class="inline-flex items-center">
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="<?php echo e(route('combos.index')); ?>"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Combos</a>
                    </div>
                </li>
                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white"><?php echo e($combo->name); ?></span>
                    </div>
                </li>
            </ol>
        </div>

        <div class="bg-white shadow-lg rounded-lg p-8 pt-0 mb-2 flex-1 overflow-auto">
            <!-- Combo Information Section -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <!-- Combo Details -->
                <div class="bg-white shadow-lg rounded-lg p-8">
                    <h3 class="text-2xl font-semibold text-gray-800 mb-6">Combo Details</h3>


                    <table class="min-w-full table-auto">
                        <tbody>
                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Combo Image</th>
                                <td class="py-3 px-4 text-gray-800">

                                    <?php if($combo->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $combo->images)); ?>" alt="Combo Image"
                                            class="w-20 h-auto rounded-md shadow-md">
                                    <?php else: ?>
                                        <p class="text-gray-500">No image available for this combo.</p>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Combo Name</th>
                                <td class="py-3 px-4 text-gray-800"><?php echo e($combo->name); ?></td>
                            </tr>
                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Description</th>
                                <td class="py-3 px-4 text-gray-700"><?php echo e($combo->description); ?></td>
                            </tr>
                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Total Price</th>
                                <td class="py-3 px-4 text-gray-800">₹<?php echo e(number_format($combo->total_price, 2)); ?></td>
                            </tr>
                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Discount Price</th>
                                <td class="py-3 px-4 text-gray-800">
                                    <?php echo e($combo->disc_price ? '₹' . number_format($combo->disc_price, 2) : 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Category</th>
                                <td class="py-3 px-4 text-gray-800"><?php echo e($combo->category->name); ?></td>
                            </tr>
                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Subcategory</th>
                                <td class="py-3 px-4 text-gray-800"><?php echo e($combo->subcategory->name); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Products in the Combo -->
                <div class="bg-white shadow-lg rounded-lg p-8">
                    <h3 class="text-2xl font-semibold text-gray-800 mb-6">Products in this Combo</h3>
                    <ul class="space-y-3">
                        <?php $__currentLoopData = $combo->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-gray-800 flex items-center flex-wrap">
                                <span
                                    class="inline-flex items-center px-4 py-2 text-sm font-semibold text-gray-800 bg-gray-300 rounded-lg border border-gray-300 hover:bg-green-50 hover:text-green-700 transition-all duration-300 mr-3 mb-3">
                                    <i class="fas fa-check-circle text-green-500 mr-2"></i>
                                    <?php echo e($product->name); ?>

                                </span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth/resources/views/combos/show.blade.php ENDPATH**/ ?>