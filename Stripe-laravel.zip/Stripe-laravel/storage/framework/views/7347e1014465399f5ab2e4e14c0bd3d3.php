<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Success Toast -->
    <?php if(session('success')): ?>
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3">
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <span><?php echo e(session('success')); ?></span>
        </div>
        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>

    <!-- Error Toast -->
    <?php if(session('error')): ?>
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3">
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <span><?php echo e(session('error')); ?></span>
        </div>
        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>

    <div class="container mx-auto mt-8 px-4">

        <!-- Cart Items -->
        <?php if($cartItems->count() > 0): ?>
            <div class="bg-white shadow-xl rounded-lg p-6 mb-8">
                <h2 class="text-3xl font-semibold mb-6 text-gray-800 flex items-center space-x-2">
                    <i class="fas fa-cart-arrow-down text-green-500"></i>
                    <span>Items in Cart</span>
                </h2>
                <table class="min-w-full table-auto border-collapse">
                    <thead class="bg-gray-100 text-gray-600">
                        <tr>
                            <th class="border px-4 py-3 text-left">Product</th>
                            <th class="border px-4 py-3 text-left">Price</th>
                            <th class="border px-4 py-3 text-left">Quantity</th>
                            <th class="border px-4 py-3 text-left">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 transition-colors duration-200">
                                <td class="border px-4 py-4 flex items-center space-x-4">
                                    <?php
                                        $images = explode(',', $item->product->images);
                                    ?>
                                    <img src="<?php echo e(!empty($images[0]) ? asset('storage/' . trim($images[0])) : asset('images/placeholder.png')); ?>"
                                        alt="<?php echo e($item->product->name); ?>" class="w-16 h-16 object-cover rounded-lg">

                                    <div class="flex flex-col items-start">
                                        <span class="text-sm font-medium"><?php echo e($item->product->name); ?></span>
                                        <span class="text-sm text-gray-600"><?php echo e($item->product->category->name); ?></span>
                                    </div>
                                </td>
                                <td class="border px-4 py-4">
                                    <span class="text-2xl">₹</span><?php echo e(number_format($item->product->price, 2)); ?>

                                </td>
                                <td class="border px-4 py-4"><?php echo e($item->quantity); ?></td>
                                <td class="border px-4 py-4">
                                    <span
                                        class="text-2xl">₹</span><?php echo e(number_format($item->product->price * $item->quantity, 2)); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Enter Delivery Address Section -->
            <div class="bg-white shadow-xl rounded-lg p-6 mb-8">
                <h2 class="text-3xl font-semibold mb-6 text-gray-800 flex items-center space-x-2">
                    <i class="fas fa-map-marker-alt text-blue-500"></i>
                    <span>Enter Delivery Address</span>
                </h2>

                <!-- Delivery Address Form -->
                <form action="<?php echo e(route('checkout.process')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <label for="address" class="block text-lg font-medium mb-2">Address</label>
                    <input type="text" id="address" name="address"
                        class="w-full p-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                        placeholder="Your address" required>
                    <div id="map" class="mt-6 w-full" style="height: 450px;"></div>

                    <!-- Hidden Fields to Store Latitude and Longitude -->
                    <input type="hidden" id="latitude" name="latitude">
                    <input type="hidden" id="longitude" name="longitude">

                    <!-- Payment Methods Header -->
                    <div class="mt-8 mb-6">
                        <h3 class="text-xl font-semibold">Select Payment Method</h3>
                    </div>

                    <!-- Payment Options -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                        <!-- Stripe Payment Option -->
                        <div class="bg-gray-100 rounded-lg shadow-md p-6 text-center transition-all hover:scale-105">
                            <i class="fab fa-stripe text-4xl text-blue-500"></i>
                            <h4 class="mt-2 font-medium text-lg">Pay with Stripe</h4>
                            <p class="text-gray-600 mt-2">Secure and fast online payments.</p>
                            <button type="submit" name="payment_method" value="stripe"
                                class="w-full bg-blue-500 text-white px-6 py-3 rounded-md font-medium hover:bg-blue-600 transition duration-300 mt-4">
                                <i class="fab fa-stripe"></i> Choose Stripe Payment
                            </button>
                        </div>

                        <!-- Cash on Delivery Option -->
                        <div class="bg-gray-100 rounded-lg shadow-md p-6 text-center transition-all hover:scale-105 mt-6">
                            <i class="fas fa-cash-register text-4xl text-green-500"></i>
                            <h4 class="mt-2 font-medium text-lg">Cash on Delivery</h4>
                            <p class="text-gray-600 mt-2">Pay with cash when your order arrives.</p>
                            <button type="submit" name="payment_method" value="cod"
                                class="w-full bg-green-500 text-white px-6 py-3 rounded-md font-medium hover:bg-green-600 transition duration-300 mt-4">
                                <i class="fas fa-cash-register"></i> Choose Cash on Delivery
                            </button>
                        </div>

                    </div>
                </form>

            </div>
        <?php else: ?>
            <div class="text-center">
                <p class="text-gray-500">No items added yet. Browse and add products to your cart to proceed with checkout.
                    <i class="fas fa-cart-arrow-down"></i>
                </p>
            </div>
        <?php endif; ?>

    </div>

    <!-- Google Maps API Script -->
    <script
        src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=places&callback=initMap&key=AIzaSyCz7Bo_xQIywAxLvk5BRR5xz70VY2VhLPk"
        async defer></script>

    <script>
        let map;
        let geocoder;
        let marker;

        function initMap() {
            if (typeof google === 'undefined') {
                console.error("Google Maps API failed to load.");
                return;
            }

            geocoder = new google.maps.Geocoder();

            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    const userLat = position.coords.latitude;
                    const userLng = position.coords.longitude;
                    const userLocation = {
                        lat: userLat,
                        lng: userLng
                    };

                    map = new google.maps.Map(document.getElementById('map'), {
                        center: userLocation,
                        zoom: 14
                    });

                    marker = new google.maps.Marker({
                        position: userLocation,
                        map: map,
                        title: "Your location"
                    });

                    document.getElementById('latitude').value = userLat;
                    document.getElementById('longitude').value = userLng;

                    google.maps.event.addListener(map, 'click', function(event) {
                        const lat = event.latLng.lat();
                        const lng = event.latLng.lng();
                        document.getElementById('latitude').value = lat;
                        document.getElementById('longitude').value = lng;
                        marker.setPosition(event.latLng);
                        geocodeLatLng(lat, lng);
                    });
                }, function() {
                    const defaultLocation = {
                        lat: 23.0260736,
                        lng: 72.5581824
                    };
                    createMapWithLocation(defaultLocation);
                });
            } else {
                const defaultLocation = {
                    lat: 23.0260736,
                    lng: 72.5581824
                };
                createMapWithLocation(defaultLocation);
            }
        }

        function createMapWithLocation(location) {
            map = new google.maps.Map(document.getElementById('map'), {
                center: location,
                zoom: 14
            });

            marker = new google.maps.Marker({
                position: location,
                map: map,
                title: "Click to select an address"
            });

            google.maps.event.addListener(map, 'click', function(event) {
                const lat = event.latLng.lat();
                const lng = event.latLng.lng();
                document.getElementById('latitude').value = lat;
                document.getElementById('longitude').value = lng;
                marker.setPosition(event.latLng);
                geocodeLatLng(lat, lng);
            });
        }

        function geocodeLatLng(lat, lng) {
            const latLng = {
                lat: lat,
                lng: lng
            };
            geocoder.geocode({
                'location': latLng
            }, function(results, status) {
                if (status === 'OK') {
                    if (results[0]) {
                        document.getElementById('address').value = results[0].formatted_address;
                    } else {
                        alert('No results found');
                    }
                } else {
                    alert('Geocoder failed due to: ' + status);
                }
            });
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth/resources/views/user/checkout.blade.php ENDPATH**/ ?>