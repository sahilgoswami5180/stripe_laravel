<?php $__env->startSection('title', 'Product Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto mt-2 min-h-screen flex flex-col">
        <!-- Breadcrumb -->
        <div class="flex px-5 py-4 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700 mb-4"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
                <!-- Home Breadcrumb -->
                <li class="inline-flex items-center">
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="<?php echo e(route('products.index')); ?>"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Products</a>
                    </div>
                </li>
                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white"><?php echo e($product->name); ?></span>
                    </div>
                </li>
            </ol>
        </div>

        <div class="bg-white shadow-lg rounded-lg p-8 pt-0 mb-2 flex-1 overflow-auto">
            <!-- Product Information Section -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <!-- Product Image -->
                <div class="bg-white shadow-lg rounded-lg p-6 flex justify-center items-center">
                    <div class="image-carousel-container relative">
                        <?php
                            $images = explode(',', $product->images); // Convert the comma-separated string into an array
                        ?>

                        <?php if(is_array($images) && count($images) > 0): ?>
                            <!-- Big Image (First Image in Reversed Array) -->
                            <div id="big-image-container" class="mb-6">
                                <img id="big-image" src="<?php echo e(asset('storage/' . $images[count($images) - 1])); ?>"
                                    alt="<?php echo e($product->name); ?>"
                                    class="zoom-image w-64 h-64 md:w-80 md:h-80 mx-auto object-contain rounded-lg shadow-md cursor-pointer transition-transform transform hover:scale-105" />
                            </div>

                            <!-- Thumbnail Images (All Images in Reversed Order) -->
                            <div id="thumbnails" class="flex space-x-6 overflow-x-auto overflow-y-hidden">
                                <?php $__currentLoopData = array_reverse($images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img src="<?php echo e(asset('storage/' . $image)); ?>" alt="<?php echo e($product->name); ?>"
                                        class="thumbnail w-20 h-20 object-cover cursor-pointer rounded-md border-2 border-transparent hover:border-blue-500 transition duration-300"
                                        data-image="<?php echo e(asset('storage/' . $image)); ?>" />
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/placeholder.png')); ?>" alt="<?php echo e($product->name); ?>"
                                class="zoom-image w-full h-auto object-cover rounded-lg shadow-md cursor-pointer transition-transform transform hover:scale-105" />
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Product Details -->
                <div class="bg-white shadow-lg rounded-lg p-8">
                    <h3 class="text-2xl font-semibold text-gray-800 mb-6">Product Details</h3>
                    <table class="min-w-full table-auto">
                        <tbody>
                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Product Name</th>
                                <td class="py-3 px-4 text-gray-800"><?php echo e($product->name); ?></td>
                            </tr>

                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Category</th>
                                <td class="py-3 px-4 text-gray-800"><?php echo e($product->category->name); ?></td>
                            </tr>
                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Price</th>
                                <td class="py-3 px-4 text-xl font-semibold text-gray-900">
                                    ₹<?php echo e(number_format($product->price, 2)); ?></td>
                            </tr>

                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Description</th>
                                <td class="py-3 px-4 text-gray-700"><?php echo e($product->description); ?></td>
                            </tr>
                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Created At</th>
                                <td class="py-3 px-4 text-gray-800"><?php echo e($product->created_at->format('Y-m-d H:i:s')); ?></td>
                            </tr>
                            <tr>
                                <th class="text-left font-medium py-3 px-4 text-gray-600">Updated At</th>
                                <td class="py-3 px-4 text-gray-800"><?php echo e($product->updated_at->format('Y-m-d H:i:s')); ?></td>
                            </tr>
                        </tbody>
                    </table>

                    <!-- Action Buttons -->
                    <div class="flex justify-center space-x-4 mt-8">
                        <a href="<?php echo e(route('products.edit', $product->id)); ?>"
                            class="px-6 py-3 bg-blue-600 text-white rounded-lg shadow-md hover:bg-blue-700 focus:ring-4 focus:ring-blue-300 transition duration-200 ease-in-out transform hover:scale-105">
                            <i class="fa-solid fa-pencil"></i> Edit
                        </a>
                        <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" class="inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                class="px-6 py-3 bg-red-600 text-white rounded-lg shadow-md hover:bg-red-700 focus:ring-4 focus:ring-red-300 transition duration-200 ease-in-out transform hover:scale-105"
                                onclick="return confirm('Are you sure you want to delete this item?')">
                                <i class="fas fa-trash-alt"></i> Delete
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Change the main image when a thumbnail is clicked
            document.querySelectorAll('.thumbnail').forEach(function(thumbnail) {
                thumbnail.addEventListener('click', function() {
                    const newSrc = thumbnail.getAttribute('data-image');
                    const bigImage = document.getElementById('big-image');
                    bigImage.src = newSrc;
                });
            });

            // Zoom functionality for the big image
            const zoomImage = document.querySelector('.zoom-image');
            let scale = 1;

            zoomImage.addEventListener('click', function() {
                const modal = document.createElement('div');
                modal.classList.add('zoomModal', 'fixed', 'inset-0', 'bg-black',
                    'bg-opacity-70', 'flex', 'justify-center', 'items-center', 'z-50');

                const zoomedImg = document.createElement('img');
                zoomedImg.src = zoomImage.src;
                zoomedImg.classList.add('max-w-full', 'h-auto', 'cursor-zoom-out', 'rounded-md');

                const closeBtn = document.createElement('button');
                closeBtn.innerHTML = 'X';
                closeBtn.classList.add('absolute', 'top-4', 'right-4', 'text-white', 'p-2',
                    'bg-black', 'bg-opacity-50', 'hover:bg-opacity-80', 'rounded-full');

                closeBtn.addEventListener('click', function() {
                    modal.remove();
                });

                modal.appendChild(zoomedImg);
                modal.appendChild(closeBtn);
                document.body.appendChild(modal);

                // Zoom in and out
                zoomedImg.addEventListener('wheel', function(event) {
                    if (event.deltaY < 0) {
                        scale = Math.min(scale + 0.1, 3); // Zoom in, limit to 3x
                    } else {
                        scale = Math.max(scale - 0.1, 1); // Zoom out, limit to 1x
                    }
                    zoomedImg.style.transform = `scale(${scale})`;
                });
            });
        });
    </script>

    <style>
        .carousel {
            position: relative;
            width: 100%;
            max-width: 300px;
            margin: 0 auto;
        }

        .carousel-images {
            display: flex;
            overflow: hidden;
        }

        .carousel-item {
            display: none;
            transition: opacity 0.5s ease-in-out;
        }

        .carousel-item img {
            width: 300px;
            height: auto;
        }

        .carousel-item.active {
            display: block;
        }

        .carousel-prev,
        .carousel-next {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.5rem;
            color: white;
            border: none;
            cursor: pointer;
            padding: 5px;
            margin-left: -50px;
            margin-right: -50px;
            border-radius: 50%;
        }

        .carousel-prev {
            left: 5px;
        }

        .carousel-next {
            right: 5px;
        }

        .zoomModal {
            transition: transform 0.3s ease-in-out;
        }

        .zoomModal img {
            max-width: 90%;
            max-height: 90%;
        }

        .thumbnail {
            transition: transform 0.3s ease;
            cursor: pointer;
        }

        .thumbnail:hover {
            transform: scale(1.1);
        }

        /* Container for the thumbnails with horizontal scrolling */
        #thumbnails {
            display: flex;
            overflow-x: auto;
            /* Allows horizontal scrolling */
            overflow-y: hidden;
            /* Disables vertical scrolling */
            gap: 8px;
        }

        /* Hide scrollbar */
        #thumbnails::-webkit-scrollbar {
            display: none;
            /* Hide the scrollbar */
        }

        /* Optional: Style scrollbar (if visible) */
        #thumbnails::-webkit-scrollbar {
            width: 8px;
        }

        #thumbnails::-webkit-scrollbar-thumb {
            background-color: #888;
            border-radius: 10px;
        }

        #thumbnails::-webkit-scrollbar-thumb:hover {
            background-color: #555;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth (copy)/resources/views/products/show.blade.php ENDPATH**/ ?>