<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>

    <!-- Include Google Fonts (Poppins) -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!-- Link to your custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Include intl-tel-input CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css">

    <!-- Include Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }

        h2,
        label {
            font-family: 'Poppins', sans-serif;
            font-weight: bold;
            /* Makes the text bold */
            font-size: 0.775rem;
            /* Minimal size (14px) */
            color: #6B7280;
            /* Grey color */
        }


        /* Custom border-radius for inputs and buttons */
        input,
        button {
            border-radius: 30px;
        }

        /* Ensure the Sign In and Sign Up links are always side by side */
        .card__header {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            /* Space between links */
            margin-bottom: 16px;
            margin-top: -5px;
        }

        .card__header span,
        .card__header a {
            /* font-weight: bold; */
            text-align: center;
            padding: 5px;
            cursor: pointer;
            text-decoration: none;
            color: #4e73df;
            margin-bottom: 30px;
            /* Default blue color */
            border-bottom: 3px solid transparent;
            transition: color 0.3s ease-in-out, border-color 0.3s ease-in-out;
            font-size: 16px;
            /* Slightly larger font size */
        }

        .card__header .card__signin {
            color: #858796;
        }

        .card__header .card__signup {
            color: #4e73df;
            border-bottom-color: #4e73df;
        }

        .card__header .card__signup:hover {
            color: #3b8bff;
            border-bottom-color: #3b8bff;
        }

        .card__header .card__signin:hover {
            color: #3b8bff;
            border-bottom-color: #3b8bff;
        }

        .main-container {
            max-width: 1000px;
            margin: auto;
            padding: 0px;
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            margin-top: 25px;
            margin-bottom: 20px;
        }

        .flex-layout {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }

        /* Image and Form layout for large screens */
        .image-container {
            display: block;
            width: 50%;
            padding-right: 1rem;
        }

        .form-container {
            width: 50%;
            padding-left: 1rem;
            margin: 25px;

        }

        /* Make form fields wrap and stack on smaller screens */
        .form-container input {
            width: 100%;
            margin-bottom: 5px;
        }

        .form-container .relative {
            margin-bottom: 10px;
        }

        /* Media Queries for Responsiveness */
        @media screen and (max-width: 1024px) {
            .flex-layout {
                flex-direction: column;
                align-items: center;
            }

            .image-container,
            .form-container {
                width: 100%;
                padding: 0;
            }

            .main-container {
                padding: 1rem;
            }
        }

        @media screen and (max-width: 768px) {
            .card__header {
                gap: 1rem;
            }

            .card__header span,
            .card__header a {
                font-size: 1rem;
            }

            .image-container {
                display: none;
            }
        }

        @media screen and (max-width: 480px) {
            .main-container {
                padding: 0.5rem;
            }

            .card__header span,
            .card__header a {
                font-size: 0.9rem;
            }
        }

        /* Disabled button styles */
        .disabled-button {
            opacity: 0.5;
            cursor: not-allowed;
        }
    </style>
</head>

<body class="bg-gray-100">
    <?php if(session('success')): ?>
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-2 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <span><?php echo e(session('success')); ?></span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-2 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <span><?php echo e(session('error')); ?></span>
        </div>

        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>

    <div class="main-container">
        <div class="card__header w-full text-center py-4">
            <span class="card__signup text-blue-500 hover:text-blue-700 font-semibold cursor-pointer">Sign up</span>
            <a href="<?php echo e(route('home')); ?>"
                class="card__signin text-blue-500 hover:text-blue-700 font-semibold cursor-pointer">Sign in</a>
        </div>

        <div class="flex-layout">
            <!-- Form Container -->
            <div class="form-container bg-white p-8 pt-0 mx-4 mr-1 w-full md:w-1/2" style="margin-top:-30px;">
                <h2 class="text-2xl font-bold text-center my-3">Register for an Account</h2>
                <form id="registerForm" action="<?php echo e(route('register')); ?>" method="POST" class="space-y-1">
                    <?php echo csrf_field(); ?>

                    <!-- Name Field -->
                    <div class="relative">
                        <label for="name" class="block text-gray-700 font-medium   mb-1">Name <span
                                class="text-red-600">*</span></label>
                        <input type="text" name="name" id="name"
                            class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Name" value="<?php echo e(old('name')); ?>" oninput="validateName()">
                        <span class="absolute right-3 text-gray-500" style="top: 30px;">
                            <i class="fas fa-user"></i>
                        </span>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Wrapper for Email and Mobile Fields -->
                    <div class="flex flex-col lg:flex-row gap-1" style="margin-top: 10px;">
                        <!-- Email Field -->
                        <div class="relative w-full">
                            <label for="email" class="block text-gray-700 font-medium   mb-1">Email <span
                                    class="text-red-600">*</span></label>
                            <input type="email" name="email" id="email"
                                class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Email" value="<?php echo e(old('email')); ?>" oninput="validateEmail()">
                            <span class="absolute right-3 text-gray-500" style="top: 30px;">
                                <i class="fas fa-envelope"></i>
                            </span>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Mobile Number Field -->
                        <div class="relative w-full">
                            <label for="mobile" class="block text-gray-700 font-medium   mb-1">Mobile Number <span
                                    class="text-red-600">*</span></label>
                            <input type="tel" name="mobile" id="mobile"
                                class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Mobile Number" value="<?php echo e(old('mobile')); ?>" pattern="[\d\s\+]*"
                                inputmode="tel" oninput="restrictInput(event)" onpaste="return false;"
                                oncopy="return false;">
                            <span class="absolute right-3
                                text-gray-500"
                                style="top: 30px;">
                                <i class="fa fa-phone-square" aria-hidden="true"></i>
                            </span>
                            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-600 mt-1 text-sm"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- Password Field -->
                    <div class="relative">
                        <label for="password" class="block text-gray-700 font-medium mb-1">Password <span
                                class="text-red-600">*</span></label>
                        <input type="password" name="password" id="password"
                            class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Password" oninput="validatePassword()" maxlength="13" onpaste="return false;"
                            oncopy="return false;">


                        <span id="toggle-password" class="absolute right-3 cursor-pointer text-gray-500"
                            style="top: 30px;" onclick="togglePassword()">
                            <i id="password-icon" class="fas fa-eye"></i>
                        </span>

                        <!-- Container for both Strength and Length counter -->
                        <div class="flex justify-between text-xs mt-1">
                            <!-- Password Strength Indicator -->
                            <span id="password-strength"
                                style="display: none; padding: 2px; background-color: gray;"></span>

                            <!-- Password Length Counter -->
                            <div class="text-right">
                                <span>Password Length: <span id="password-length-counter">0</span> / 13</span>
                            </div>
                        </div>

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Confirm Password Field -->
                    <div class="relative">
                        <label for="password_confirmation" class="block text-gray-700 font-medium   mb-1">Confirm
                            Password <span class="text-red-600">*</span></label>
                        <input type="password" name="password_confirmation" id="password_confirmation"
                            class="w-full mb-4 border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="Confirm Password" oninput="validatePasswordConfirmation()" maxlength="13"
                            onpaste="return false;" oncopy="return false;">

                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-600 mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Register Button -->
                    <button type="submit" id="register-btn"
                        class="w-full bg-blue-500 text-white py-2 rounded-lg hover:bg-blue-600 transition disabled-button"
                        disabled>Register</button>
                </form>

            </div>

            <!-- Left side (Image) -->
            <div class="image-container">
                <img src="https://img.freepik.com/free-vector/sign-up-concept-illustration_114360-7965.jpg?size=338&ext=jpg&ga=GA1.1.2008272138.1721174400&semt=ais_user"
                    alt="Register Image" class="w-full h-full object-cover rounded-lg" style="margin-top: -40px;">
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"></script>

    <script>
        // Initialize intl-tel-input on mobile number field
        var input = document.querySelector("#mobile");
        var iti = window.intlTelInput(input, {
            initialCountry: "in", // Set default country to India
            geoIpLookup: function(callback) {
                fetch('https://ipinfo.io', {
                        method: 'GET'
                    })
                    .then(response => response.json())
                    .then(data => callback(data.country))
                    .catch(() => callback('us'));
            },
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js"
        });

        // Reorder the country options list to put India at the top
        iti.promise.then(function() {
            var countryList = document.querySelectorAll('.iti__country');
            var indiaOption = Array.from(countryList).find(option => option.getAttribute('data-country-code') ===
                'in');
            if (indiaOption) {
                indiaOption.parentNode.insertBefore(indiaOption, indiaOption.parentNode.firstChild);
            }
        });

        // Add event listener to the form to update the mobile number field before submission
        document.querySelector("#registerForm").addEventListener("submit", function(e) {
            // Get the full number including the country code using the intl-tel-input getNumber() method
            var fullMobileNumber = iti.getNumber();

            // Set the full mobile number (with country code) into the mobile input field
            document.querySelector("#mobile").value = fullMobileNumber;
        });
    </script>
    <script>
        // Function to toggle password visibility
        function togglePassword() {
            var passwordField = document.getElementById("password");
            var passwordIcon = document.getElementById("password-icon");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                passwordIcon.classList.remove("fa-eye");
                passwordIcon.classList.add("fa-eye-slash");
            } else {
                passwordField.type = "password";
                passwordIcon.classList.remove("fa-eye-slash");
                passwordIcon.classList.add("fa-eye");
            }
        }

        // Password validation function to check length and format (uppercase, lowercase, symbol, digit)
        function validatePassword() {
            const password = document.getElementById("password").value;
            const passwordLength = password.length;
            const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,13}$/;

            // Update the password length counter
            document.getElementById("password-length-counter").innerText = passwordLength;

            // Set color for the password strength
            setPasswordStrengthColor(passwordLength, password);

            // Check if password matches the pattern and is within the valid length range
            return regex.test(password) && passwordLength >= 8 && passwordLength <= 13;
        }

        // Set the color of the password strength indicator based on length and validity
        function setPasswordStrengthColor(passwordLength, password) {
            const strengthLabel = document.getElementById("password-strength");

            // Hide the indicator completely if password length is 0
            if (passwordLength === 0) {
                strengthLabel.style.display = "none"; // Hide the indicator
                return;
            }

            // Show the strength indicator
            strengthLabel.style.display = "inline-block"; // Ensure it is visible

            // Password strength conditions
            if (passwordLength < 8) {
                strengthLabel.innerText = "Poor";
                strengthLabel.style.color = "red";
                strengthLabel.style.backgroundColor = "#FFCCCC"; // Light red background
            } else if (passwordLength >= 8 && passwordLength <= 12) {
                strengthLabel.innerText = "Not Strong";
                strengthLabel.style.color = "#ffff10"; // Bright yellow text color
                strengthLabel.style.backgroundColor = "#242400"; // Dark yellow background
            } else if (passwordLength > 12 && /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,13}$/
                .test(password)) {
                strengthLabel.innerText = "Strong";
                strengthLabel.style.color = "green";
                strengthLabel.style.backgroundColor = "#CCFFCC"; // Light green background
            } else {
                // If the password doesn't meet the strength criteria, hide the indicator
                strengthLabel.innerText = "";
                strengthLabel.style.color = "transparent";
                strengthLabel.style.backgroundColor = "transparent";
                strengthLabel.style.display = "none"; // Hide the indicator
            }
        }

        // Enable/Disable Register Button based on form validity
        const registerBtn = document.getElementById("register-btn");
        const form = document.getElementById("registerForm");

        form.addEventListener("input", function() {
            // Manually check if each required field is filled in
            const name = document.getElementById("name").value.trim();
            const email = document.getElementById("email").value.trim();
            const mobile = document.getElementById("mobile").value.trim();
            const password = document.getElementById("password").value.trim();
            const passwordConfirmation = document.getElementById("password_confirmation").value.trim();

            // Validate password length and format
            const passwordValid = validatePassword();

            // Enable the button if all fields are filled out and password is valid
            if (name && email && mobile && password && passwordConfirmation && password === passwordConfirmation &&
                passwordValid) {
                registerBtn.disabled = false;
                registerBtn.classList.remove("disabled-button");
            } else {
                registerBtn.disabled = true;
                registerBtn.classList.add("disabled-button");
            }
        });
    </script>

</body>

</html>
<?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth/resources/views/auth/register.blade.php ENDPATH**/ ?>