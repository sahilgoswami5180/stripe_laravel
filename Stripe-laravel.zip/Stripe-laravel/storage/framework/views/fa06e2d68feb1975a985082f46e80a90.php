    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>

        <!-- Include Swiper JS and CSS -->
        <link href="https://unpkg.com/swiper/swiper-bundle.min.css" rel="stylesheet">
        <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
        <script src="https://cdn.tailwindcss.com"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.min.css">
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.min.css">
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-table/1.24.0/bootstrap-table.min.js">

        <script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.7/chosen.jquery.min.js"></script>

        <!-- Add Font Awesome CDN -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
        <?php echo $__env->yieldPushContent('head'); ?> <!-- For any additional head content -->
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
            @import url('https://fonts.googleapis.com/css2?family=Turret+Road:wght@200;300;400;500;700;800&display=swap');

            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
                list-style: none;
                font-family: 'Poppins', sans-serif;
                text-decoration: none;
            }

            .main {
                width: 100%;
                background-color: #FFFFFF;
                height: 100vh;
            }

            .side-navbar {
                left: 0;
                position: fixed;
                height: 100vh;
                width: 260px;
                background: url('https://i.postimg.cc/054d9xdf/img.jpg');
                overflow: hidden;
                transition: .5s ease;
            }

            .side-navbar.active {
                width: 80px;
            }

            .side-navbar ul,
            span {
                top: 0;
                left: 0;
                width: 100%;
            }

            .side-navbar ul li {
                width: 100%;
            }

            .side-navbar ul li:first-child {
                margin-bottom: 1rem;
                background: none;
            }

            .side-navbar ul li a {
                display: block;
                width: 100%;
                display: flex;
                background-color: #FFFFFF;
                color: black;
            }

            .side-navbar ul li a .icon {
                min-width: 80px;
                display: block;
                font-size: 25px;
                padding-right: 10px;
                line-height: 60px;
                height: 60px;
                text-align: center;
            }

            .side-navbar ul li a .text {
                display: block;
                padding: 0px;
                line-height: 60px;
                height: 60px;
                white-space: nowrap;
            }

            .side-navbar ul li a h2 {
                font-family: 'Turret Road';
            }

            .content {
                position: absolute;
                width: calc(100% - 250px);
                left: 250px;
                min-height: auto;
                transition: .5s ease;
                /* background-image: url('https://i.postimg.cc/prv7bv98/pexels-philippedonn-1114690.jpg'); */
                background-color: whitesmoke;
                background-position: center;
                background-size: cover;

            }

            .content.active {
                width: calc(100% - 60px);
                left: 60px;
            }

            .top-navbar {
                width: 100%;
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 7px 20px;
                box-shadow: 0 2px 4px rgb(0 0 0 / 10%);
            }

            /* .profile img {
                width: 44px;
                height: 44px;
                object-fit: contain;
                object-position: center;
                border-radius: 50%;
                cursor: pointer;
            } */

            #menu-icon {
                font-size: 28px;
                cursor: pointer;
                color: black;
            }

            /*MEDIA QUERIES*/

            @media (max-width: 768px) {
                .content {
                    width: 100%;
                    left: 0;
                }

                .content.active {
                    width: calc(100% - 250px);
                    left: 250px;
                }

                .side-navbar {
                    width: 250px;
                    left: 0px;
                }

                .side-navbar.active {
                    left: 0;
                    width: 250px;
                }
            }



            /* Custom scrollbar styles */
            body::-webkit-scrollbar {
                width: 10px;
            }

            body::-webkit-scrollbar-track {
                background: #f1f1f1;
                border-radius: 10px;
            }

            body::-webkit-scrollbar-thumb {
                background: #888;
                border-radius: 10px;
            }

            body::-webkit-scrollbar-thumb:hover {
                background: #555;
            }

            For better mobile support @media (max-width: 768px) {
                .sidebar {
                    position: fixed;
                    left: -100%;
                    top: 0;
                    width: 250px;
                    z-index: 1000;
                    transition: 0.3s;
                }

                .sidebar.open {
                    left: 0;
                }

                .main-content {
                    margin-left: 0;
                }

                .navbar {
                    padding: 0.5rem;
                }
            }
        </style>
    </head>

    <body class="bg-gray-100">
        <!-- Sidebar -->
        <div id="sidebar"
            class="side-navbar sidebar bg-gradient-to-b from-blue-600 to-blue-800 text-white w-64 p-4 shadow-lg">
            <div class="flex flex-col items-center mb-2">
                <span class="font-semibold text-2xl px-4 pl-0">
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="flex items-center text-sm font-semibold hover:text-blue-200 transition duration-300 ease-in-out transform   p-2 rounded-lg hover:bg-blue-700">
                        <i class="fas fa-tachometer-alt w-6 h-6 text-2xl mr-4"></i> Dashboard
                    </a>
                </span>
                <div class="text-center mt-1">
                    <span id="last-login-time" class="text-gray-300 text-xs">
                        Last Login: <span class="font-semibold">3 days ago</span>
                    </span>
                </div>
            </div>
            <hr class="w-full border-gray-700 mb-6">
            <ul class="space-y-6">
                <!-- Categories Dropdown -->
                <li>
                    <button
                        class="flex items-center w-full text-sm font-semibold hover:text-blue-200 focus:outline-none transition duration-300 ease-in-out transform   p-2 rounded-lg hover:bg-blue-700"
                        id="categoriesDropdownToggle">
                        <i class="fas fa-list w-5 h-5 mr-4"></i> Categories
                        <i class="fas fa-chevron-down ml-2 transform transition-transform duration-200"
                            id="categoriesDropdownArrow"></i>
                    </button>
                    <ul class="space-y-2 mt-2 pl-6 hidden bg-gradient-to-r from-white to-white rounded-lg shadow-md p-4 transition-all ease-in-out duration-300"
                        id="categoriesDropdown" aria-labelledby="categoriesDropdownToggle">
                        <li>
                            <a href="<?php echo e(route('categories.index')); ?>"
                                class="text-gray-900 hover:text-black transition duration-200 transform   text-xs">
                                <i class="fas fa-eye mr-2"></i> View Categories
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('categories.create')); ?>"
                                class="text-gray-900 hover:text-black transition duration-200 transform   text-xs">
                                <i class="fas fa-plus-circle mr-2"></i> Add New Category
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Subcategories Dropdown -->
                <li>
                    <button
                        class="flex items-center w-full text-sm font-semibold hover:text-blue-200 focus:outline-none transition duration-300 ease-in-out transform   p-2 rounded-lg hover:bg-blue-700"
                        id="subcategoriesDropdownToggle">
                        <i class="fas fa-box w-5 h-5 mr-4"></i> Subcategories
                        <i class="fas fa-chevron-down ml-2 transform transition-transform duration-200"
                            id="subcategoriesDropdownArrow"></i>
                    </button>
                    <ul class="space-y-2 mt-2 pl-6 hidden bg-gradient-to-r from-white to-white rounded-lg shadow-md p-4 transition-all ease-in-out duration-300"
                        id="subcategoriesDropdown" aria-labelledby="subcategoriesDropdownToggle">
                        <li>
                            <a href="<?php echo e(route('subcategories.index')); ?>"
                                class="text-gray-900 hover:text-black transition duration-200 transform   text-xs">
                                <i class="fas fa-eye mr-2"></i> View Subcategories
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('subcategories.create')); ?>"
                                class="text-gray-900 hover:text-black transition duration-200 transform   text-xs">
                                <i class="fas fa-plus-circle mr-2"></i> Add New Subcategory
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Products Dropdown -->
                <li>
                    <button
                        class="flex items-center w-full text-sm font-semibold hover:text-blue-200 focus:outline-none transition duration-300 ease-in-out transform   p-2 rounded-lg hover:bg-blue-700"
                        id="productsDropdownToggle">
                        <i class="fas fa-cube w-5 h-5 mr-4"></i> Products
                        <i class="fas fa-chevron-down ml-2 transform transition-transform duration-200"
                            id="productsDropdownArrow"></i>
                    </button>
                    <ul class="space-y-2 mt-2 pl-6 hidden bg-gradient-to-r from-white to-white rounded-lg shadow-md p-4 transition-all ease-in-out duration-300"
                        id="productsDropdown" aria-labelledby="productsDropdownToggle">
                        <li>
                            <a href="<?php echo e(route('products.index')); ?>"
                                class="text-gray-900 hover:text-black transition duration-200 transform   text-xs">
                                <i class="fas fa-eye mr-2"></i> View Products
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('products.create')); ?>"
                                class="text-gray-900 hover:text-black transition duration-200 transform   text-xs">
                                <i class="fas fa-plus-circle mr-2"></i> Add New Product
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Combos Dropdown -->
                <li>
                    <button
                        class="flex items-center w-full text-sm font-semibold hover:text-blue-200 focus:outline-none transition duration-300 ease-in-out transform   p-2 rounded-lg hover:bg-blue-700"
                        id="combosDropdownToggle">
                        <i class="fas fa-cogs w-5 h-5 mr-4"></i> Manage Combos
                        <i class="fas fa-chevron-down ml-2 transform transition-transform duration-200"
                            id="combosDropdownArrow"></i>
                    </button>
                    <ul class="space-y-2 mt-2 pl-6 hidden bg-gradient-to-r from-white to-white rounded-lg shadow-md p-4 transition-all ease-in-out duration-300"
                        id="combosDropdown" aria-labelledby="combosDropdownToggle">
                        <li>
                            <a href="<?php echo e(route('combos.index')); ?>"
                                class="text-gray-900 hover:text-black transition duration-200 transform   text-xs">
                                <i class="fas fa-list mr-2"></i> View Combos
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('combos.create')); ?>"
                                class="text-gray-900 hover:text-black transition duration-200 transform   text-xs">
                                <i class="fas fa-plus-circle mr-2"></i> Create Combo
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- User Dropdown -->
                <li>
                    <button
                        class="flex items-center w-full text-sm font-semibold hover:text-blue-200 focus:outline-none transition duration-300 ease-in-out transform   p-2 rounded-lg hover:bg-blue-700"
                        id="userDropdownToggle">
                        <i class="fas fa-users w-5 h-5 mr-4"></i> User Details
                        <i class="fas fa-chevron-down ml-2 transform transition-transform duration-200"
                            id="userDropdownArrow"></i>
                    </button>
                    <ul class="space-y-2 mt-2 pl-6 hidden bg-gradient-to-r from-white to-white rounded-lg shadow-md p-4 transition-all ease-in-out duration-300"
                        id="userDropdown" aria-labelledby="userDropdownToggle">
                        <li>
                            <a href="<?php echo e(route('user_details.index')); ?>"
                                class="text-gray-900 hover:text-black transition duration-200 transform   text-xs">
                                <i class="fas fa-eye mr-2"></i> View User Details
                            </a>
                        </li>
                    </ul>
                </li>

                <!-- Orders -->
                <li>

                    <a href="<?php echo e(route('order.index')); ?>"
                        class="flex items-center bg-blue-500 text-sm font-semibold transition duration-300 ease-in-out transform   p-2 rounded-lg">
                        <i class="fas fa-tachometer-alt w-5 h-5 mr-4"></i> Orders
                    </a>

                </li>
            </ul>
        </div>


        <!-- Main Content -->
        <div class="content flex flex-col">
            <nav class="navbar bg-white border-b-2 border-blue-700 shadow-md sticky top-0 z-10 p-4 flex justify-between items-center"
                style="z-index: 50;">
                
                <div class='bx bx-menu'><i class="fa fa-bars" id="menu-icon"></i></div>

                <?php if(auth()->guard()->check()): ?>

                    <div class="relative flex items-center space-x-2">


                        <button class="flex items-center space-x-2 text-gray-700 hover:text-blue-500"
                            id="profileNavbarDropdownToggle" aria-expanded="false" style="margin-right: 5px;">
                            <img id="profileImagePreview"
                                src="<?php echo e(asset('storage/' . (Auth::user()->profile_image ?? 'profile_images/Profile.png'))); ?>"
                                alt="Profile Picture"
                                class="w-8 h-8 rounded-full object-cover border-2 border-white-500 shadow-lg">
                            <p class="px-1"><?php echo e(Auth::user()->name); ?></p>
                            <i class="fas fa-chevron-down w-5 h-5 transform transition-transform duration-200"
                                id="navbarDropdownArrow"></i>
                        </button>
                        <!-- Dropdown menu -->
                        <ul class="absolute right-2 rounded-lg bg-white shadow-2xl hidden" id="profileNavbarDropdown"
                            aria-labelledby="profileNavbarDropdownToggle"
                            style=" margin-right:-15px; width:200px; margin-top: 215px;">
                            <li>
                                <a href="<?php echo e(route('profile')); ?>" class="block px-1 py-2 text-gray-700 hover:bg-gray-100">
                                    <i class="fas fa-user ml-3"></i><span class="pl-2">My Profile</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('change-password.form')); ?>"
                                    class="block px-1 py-2 text-gray-700 nowrap hover:bg-gray-100">
                                    <i class="fas fa-lock ml-3"></i><span class="pl-2">Change Password</span>
                                </a>
                            </li>
                            <hr>
                            <li class="flex justify-center items-center">
                                <button onclick="openLogoutModal()"
                                    class="bg-red-600 px-8 py-1 m-2 rounded hover:bg-red-700 text-white text-lg font-semibold flex items-center">
                                    <i class="fas fa-sign-out-alt mr-2"></i> Logout
                                </button>
                                <form id="logoutForm" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>

                    </div>
                <?php endif; ?>

                <?php if(auth()->guard()->guest()): ?>
                    <div>
                        <a href="<?php echo e(route('login')); ?>" class="text-gray-700 hover:text-blue-500">Login</a>
                    </div>
                <?php endif; ?>
            </nav>

            <div class="main-content flex flex-col w-full">
                <!-- Page Content -->
                <main class="py-6 px-4 overflow-auto" style="min-height: 100vh;">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
                <!-- Footer -->
                <footer class="bg-gradient-to-r from-blue-500 to-blue-600 text-white py-2 mt-auto">
                    <div class="max-w-screen-xl mx-auto flex justify-between items-center px-4 sm:px-6">
                        <div class="text-sm">
                            <p>&copy; 2024 Your Company. All rights reserved.</p>
                        </div>
                        <div class="flex items-center space-x-4">
                            <a href="#" class="text-gray-300 hover:text-white transition-colors">
                                <i class="fab fa-facebook-square text-2xl"></i>
                            </a>
                            <a href="#" class="text-gray-300 hover:text-white transition-colors">
                                <i class="fab fa-twitter-square text-2xl"></i>
                            </a>
                            <a href="#" class="text-gray-300 hover:text-white transition-colors">
                                <i class="fab fa-linkedin text-2xl"></i>
                            </a>
                            <a href="#" class="text-gray-300 hover:text-white transition-colors">
                                <i class="fab fa-instagram-square text-2xl"></i>
                            </a>
                        </div>
                    </div>
                </footer>
            </div>
        </div>

        <!-- Logout Confirmation Modal -->
        <div id="logoutModal" class="fixed inset-0 flex items-center justify-center bg-gray-800 bg-opacity-50 hidden">
            <div class="bg-white p-4 rounded-lg shadow-lg w-full max-w-xl">
                <div class="flex items-center mb-4">
                    <i class="fas fa-exclamation-circle text-red-600 text-3xl mr-4"></i>
                    <h2 class="text-xl font-semibold text-gray-800">Are you sure you want to log out?</h2>
                </div>
                <p class="text-gray-700 mb-4 text-center">If you log out, you will need to sign in again to continue
                    using
                    the application.</p>
                <div class="flex justify-end gap-4 mt-6">
                    <button onclick="closeLogoutModal()"
                        class="flex items-center justify-center px-6 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 transition duration-300">
                        <i class="fas fa-times-circle mr-2"></i> Cancel
                    </button>
                    <button onclick="document.getElementById('logoutForm').submit();"
                        class="flex items-center justify-center px-6 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition duration-300">
                        <i class="fas fa-sign-out-alt mr-2"></i> Logout
                    </button>
                </div>
            </div>
        </div>
        <script>
            // Function to toggle dropdown visibility
            function toggleDropdown(id, arrowId) {
                const dropdown = document.getElementById(id);
                const arrow = document.getElementById(arrowId);

                dropdown.classList.toggle('hidden');
                arrow.classList.toggle('rotate-180');
            }

            // Language change handler
            function changeLanguage(language) {
                // Set the selected language text
                const selectedLanguageText = language === 'en' ? 'English' : (language === 'es' ? 'Spanish' : 'French');
                document.getElementById('selectedLanguage').textContent = selectedLanguageText;

                // For demo purposes, you can store the language in local storage or trigger the translation action here
                localStorage.setItem('selectedLanguage', language);
                // Optionally trigger language change in the backend if needed
                // Example: fetch(`/change-language?lang=${language}`);
            }

            // Language dropdown toggle event
            document.getElementById('languageDropdownToggle').addEventListener('click', () => toggleDropdown(
                'languageDropdown', 'languageDropdownArrow'));

            // Optional: On page load, check if a language has been previously selected
            window.onload = function() {
                const savedLanguage = localStorage.getItem('selectedLanguage') || 'en';
                changeLanguage(savedLanguage);
            };
        </script>

        <script>
            // Function to preview the selected image
            function previewImage(event) {
                const file = event.target.files[0];
                const preview = document.getElementById('profileImagePreview');

                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        preview.src = e.target.result;
                    }
                    reader.readAsDataURL(file);
                } else {
                    preview.src = '<?php echo e(asset('storage/' . (Auth::user()->profile_image ?? 'profile_images/default.jpg'))); ?>';
                }
            }

            // Dropdown toggle functions
            function toggleDropdown(id, arrowId) {
                const dropdown = document.getElementById(id);
                const arrow = document.getElementById(arrowId);

                dropdown.classList.toggle('hidden');
                arrow.classList.toggle('rotate-180');
            }

            document.getElementById('categoriesDropdownToggle').addEventListener('click', () => toggleDropdown(
                'categoriesDropdown', 'categoriesDropdownArrow'));
            // Event listeners for the toggle buttons
            document.getElementById('subcategoriesDropdownToggle').addEventListener('click', () => toggleDropdown(
                'subcategoriesDropdown', 'subcategoriesDropdownArrow'));
            document.getElementById('productsDropdownToggle').addEventListener('click', () => toggleDropdown(
                'productsDropdown', 'productsDropdownArrow'));
            document.getElementById('combosDropdownToggle').addEventListener('click', () => toggleDropdown(
                'combosDropdown', 'combosDropdownArrow'));

            document.getElementById('userDropdownToggle').addEventListener('click', () => toggleDropdown(
                'userDropdown', 'userDropdownArrow'));

            document.getElementById('profileNavbarDropdownToggle').addEventListener('click', () => toggleDropdown(
                'profileNavbarDropdown', 'navbarDropdownArrow'));

            // Open logout confirmation modal
            function openLogoutModal() {
                document.getElementById('logoutModal').classList.remove('hidden');
            }

            // Close logout confirmation modal
            function closeLogoutModal() {
                document.getElementById('logoutModal').classList.add('hidden');
            }

            window.onload = function() {
                const cookies = document.cookie.split('; ');
                console.log(cookies); // Log the cookies to check if `user_data` exists
                let lastLoginTimeCookie = '';
                cookies.forEach(cookie => {
                    const [key, value] = cookie.split('=');
                    if (key === 'user_data') {
                        try {
                            const userData = JSON.parse(decodeURIComponent(value));
                            console.log(userData); // Check if `userData` has the expected structure
                            if (userData.last_login_at) {
                                lastLoginTimeCookie = userData.last_login_at;
                            }
                        } catch (e) {
                            console.error('Error parsing user data cookie', e);
                        }
                    }
                });

                if (lastLoginTimeCookie) {
                    const lastLoginDate = new Date(lastLoginTimeCookie);
                    const lastLoginFormatted = lastLoginDate.toLocaleString();
                    document.getElementById('last-login-time').textContent = `Last login: ${lastLoginFormatted}`;
                } else {
                    document.getElementById('last-login-time').textContent = 'Last login: N/A';
                }
            };
        </script>
        <script>
            let menu = document.querySelector('#menu-icon');
            let sidenavbar = document.querySelector('.side-navbar');
            let content = document.querySelector('.content');

            menu.onclick = () => {
                sidenavbar.classList.toggle('active');
                content.classList.toggle('active');
            }
        </script>

        <?php echo $__env->yieldPushContent('scripts'); ?> <!-- For any page-specific scripts -->
    </body>

    </html>
<?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth (copy)/resources/views/layouts/app.blade.php ENDPATH**/ ?>