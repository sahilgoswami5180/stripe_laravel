<?php $__env->startSection('title', 'Payment Canceled'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-12">
    <div class="container mx-auto text-center">
        <h1 class="text-4xl font-bold text-red-500 mb-4">Payment Canceled</h1>
        <p class="text-lg">Your payment was canceled. Please try again or contact support if you have any issues.</p>
        <a href="<?php echo e(route('user.cart')); ?>" class="text-blue-500 mt-4 inline-block">Go Back to Cart</a>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth (copy)/resources/views/user/cancel.blade.php ENDPATH**/ ?>