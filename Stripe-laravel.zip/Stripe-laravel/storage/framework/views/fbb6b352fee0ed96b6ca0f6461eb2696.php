<?php $__env->startSection('title', 'Create Product'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto mt-0">

        <!-- Breadcrumb -->
        <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
            aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse">
                <!-- Home Breadcrumb -->
                <li class="inline-flex items-center">
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                        <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                            viewBox="0 0 20 20">
                            <path
                                d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                        </svg>
                        Home
                    </a>
                </li>

                <!-- Separator -->
                <li>
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <a href="<?php echo e(route('products.index')); ?>"
                            class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Products</a>
                    </div>
                </li>

                <!-- Current Page -->
                <li aria-current="page">
                    <div class="flex items-center">
                        <svg class="rtl:rotate-180 w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                            xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="m1 9 4-4-4-4" />
                        </svg>
                        <span class="ms-1 text-sm font-medium text-gray-500 md:ms-2 dark:text-gray-400">Create
                            Products</span>
                    </div>
                </li>
            </ol>
        </div>

        <!-- Full-Screen Width Card Container for the Form -->
        <div class="w-full bg-white p-8 rounded-lg shadow-xl">

            <!-- Flex container to align Button and Page Title -->
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-3xl font-semibold text-gray-800"><i class="fas fa-plus-circle mr-2"></i> Add New Product
                </h2>
            </div>

            <!-- Form to Create Product -->
            <form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
                <?php echo csrf_field(); ?>

                <!-- Flex container for category and subcategory -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <!-- Product Category -->
                    <div>
                        <label for="category_id" class="block text-sm font-medium text-gray-700">Category <span
                                class="text-red-500">*</span></label>
                        <select name="category_id" id="category_id"
                            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">Select Category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                    <?php echo e(old('category_id') == $category->id ? 'selected' : ''); ?>>
                                    <?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Product Subcategory (Based on Category) -->
                    <div>
                        <label for="subcategory_id" class="block text-sm font-medium text-gray-700">Subcategory <span
                                class="text-red-500">*</span></label>
                        <select name="subcategory_id" id="subcategory_id"
                            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">Select Subcategory</option>
                        </select>
                        <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Flex container for product name and price -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <!-- Product Name -->
                    <div>
                        <label for="name" class="block text-sm font-medium text-gray-700">Product Name <span
                                class="text-red-500">*</span></label>
                        <div class="relative">
                            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>"
                                class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <i class="fas fa-tag absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        </div>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Product Price -->
                    <div>
                        <label for="price" class="block text-sm font-medium text-gray-700">Product Price <span
                                class="text-red-500">*</span></label>
                        <div class="relative">
                            <input type="number" name="price" id="price" value="<?php echo e(old('price')); ?>" step="0.01"
                                min="0"
                                class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <i
                                class="fas fa-dollar-sign absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        </div>
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Product Description -->
                <div class="mb-6">
                    <label for="description" class="block text-sm font-medium text-gray-700">Product Description <span
                            class="text-red-500">*</span></label>
                    <div class="relative flex flex-col">
                        <textarea name="description" id="description" rows="4" maxlength="255" oninput="updateCharCount()"
                            class="mt-1 block w-full px-4 py-2 pr-10 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo e(old('description')); ?></textarea>
                        <i class="fas fa-pencil-alt absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- Character Counter at the end of the same line as the textarea -->
                    <div class="right-18 text-sm text-gray-500 mt-1">
                        <span id="charCount" class="text-sm text-gray-500">0 / 255</span>
                    </div>
                </div>

                <!-- Product Images (Multiple files) -->
                <div class="mb-6">
                    <label for="images" class="block text-sm font-medium text-gray-700">Product Images</label>
                    <input type="file" name="images[]" id="images" accept="image/*" multiple
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <!-- Image Preview -->
                    <div id="imagePreviews" class="mt-2 flex space-x-4"></div>
                </div>

                <!-- Product Status (Selector) -->
                <div class="mb-6">
                    <label for="status" class="block text-sm font-medium text-gray-700">Product Status <span
                            class="text-red-500">*</span></label>
                    <select name="status" id="status"
                        class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="" disabled <?php echo e(old('status') ? '' : 'selected'); ?>>Please choose a status
                        </option>
                        <option value="active" <?php echo e(old('status', 'active') == 'active' ? '' : ''); ?>>Active</option>
                        <option value="inactive" <?php echo e(old('status', 'inactive') == 'inactive' ? '' : 'selected'); ?>>Inactive
                        </option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Submit Button -->
                <div class="flex justify-end space-x-4">
                    <a href="<?php echo e(route('products.index')); ?>"
                        class="bg-gray-300 text-gray-800 px-6 py-2 rounded hover:bg-gray-400 transition duration-300 flex items-center">
                        <i class="fas fa-times-circle mr-2"></i> Cancel
                    </a>
                    <button type="submit"
                        class="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition duration-300 flex items-center">
                        <i class="fas fa-check-circle mr-2"></i> Create Product
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Zoom Modal -->
    <div id="zoomModal"
        class="fixed inset-0 bg-black bg-opacity-50 hidden justify-center items-center z-50 transition-all duration-300 ease-in-out">
        <div class="relative w-auto max-w-4xl m-auto bg-white rounded-lg shadow-lg overflow-hidden">
            <!-- Zoomed Image -->
            <img id="zoomedImg" class="max-w-full h-auto rounded-md" />

            <!-- Close Button with Icon -->
            <button id="closeZoom"
                class="absolute top-4 right-5 text-white p-2 bg-black bg-opacity-50 hover:bg-opacity-80 rounded-full transition-all duration-200">
                <i class="fas fa-times"></i> <!-- Font Awesome Icon -->
            </button>
        </div>
    </div>


    <script>
        // When the category changes, make an AJAX call to get the subcategories
        document.getElementById('category_id').addEventListener('change', function() {
            const categoryId = this.value;
            const subcategoryDropdown = document.getElementById('subcategory_id');

            // Clear previous subcategory options
            subcategoryDropdown.innerHTML = '<option value="">Select Subcategory</option>';

            if (categoryId) {
                // Make an AJAX request to fetch subcategories based on the selected category
                fetch(`/get-subcategories/${categoryId}`)
                    .then(response => response.json())
                    .then(data => {
                        // Check if subcategories are available
                        if (data.length > 0) {
                            data.forEach(subcategory => {
                                const option = document.createElement('option');
                                option.value = subcategory.id;
                                option.textContent = subcategory.name;
                                subcategoryDropdown.appendChild(option);
                            });
                        } else {
                            // If no subcategories are available
                            const option = document.createElement('option');
                            option.value = '';
                            option.textContent = 'No subcategories available';
                            subcategoryDropdown.appendChild(option);
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching subcategories:', error);
                    });
            }
        });

        // Character Counter
        function updateCharCount() {
            const description = document.getElementById('description');
            const charCount = document.getElementById('charCount');
            charCount.textContent = description.value.length + ' / 255';
        }

        // Image preview
        document.getElementById('images').addEventListener('change', function(event) {
            const files = event.target.files;
            const imagePreviews = document.getElementById('imagePreviews');
            imagePreviews.innerHTML = ''; // Clear previous previews

            // Loop through selected files and create image preview
            Array.from(files).forEach(file => {
                const reader = new FileReader();

                reader.onload = function(e) {
                    const img = document.createElement('img');
                    img.src = e.target.result;
                    img.classList.add('w-12', 'h-12', 'object-cover', 'rounded-md', 'cursor-pointer');
                    imagePreviews.appendChild(img);

                    // Add click event for zoom functionality
                    img.addEventListener('click', function() {
                        openZoomModal(e.target.result);
                    });
                };

                reader.readAsDataURL(file);
            });
        });

        // Zoom modal functionality
        function openZoomModal(imgSrc) {
            const zoomModal = document.getElementById('zoomModal');
            const zoomedImg = document.getElementById('zoomedImg');
            zoomedImg.src = imgSrc;
            zoomModal.classList.remove('hidden'); // Show modal
        }

        // Close zoom modal
        document.getElementById('closeZoom').addEventListener('click', function() {
            const zoomModal = document.getElementById('zoomModal');
            zoomModal.classList.add('hidden'); // Hide modal
        });

        // Allow zoom in/out by scrolling on the modal
        let zoomLevel = 1;
        document.getElementById('zoomModal').addEventListener('wheel', function(event) {
            if (event.deltaY < 0) {
                zoomLevel += 0.1; // Zoom in
            } else {
                zoomLevel -= 0.1; // Zoom out
            }
            zoomLevel = Math.max(0.5, Math.min(3, zoomLevel)); // Limit zoom level
            document.getElementById('zoomedImg').style.transform = `scale(${zoomLevel})`;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth (copy)/resources/views/products/create.blade.php ENDPATH**/ ?>