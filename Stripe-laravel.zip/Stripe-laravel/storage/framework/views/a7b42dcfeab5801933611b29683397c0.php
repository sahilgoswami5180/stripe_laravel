
<?php $__env->startSection('title', '404'); ?>  <!-- Set the title dynamically -->

<?php $__env->startSection('body-class', 'bg-gradient-primary'); ?>  <!-- Add a custom class to the body if needed -->

<?php $__env->startSection('content'); ?>
    <!-- 404 Page Section -->
    <section class="page_404">
        <div class="container mx-auto">
            <div class="row justify-center">
                <div class="col-lg-12 text-center">
                    <!-- 404 Error Background Image -->
                    <div class="four_zero_four_bg">
                        <h1>404</h1>
                    </div>

                    <!-- Content Box for Error Message -->
                    <div class="contant_box_404">
                        <h2 class="h2">
                            Look like you're lost
                        </h2>
                        <p>The page you are looking for is not available!</p>
                        <a href="<?php echo e(route('home')); ?>" class="link_404">Go to Home</a>  <!-- Use Laravel's route helper -->
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .page_404 {
            width: 100%;
            overflow-x: hidden;
            justify-content: center;
            background: #fff;
            font-family: 'Arvo', serif;
        }

        .page_404 img {
            /* width: 100%; */
            margin-left: 50px;
        }

        .four_zero_four_bg {
            background-image: url(https://cdn.dribbble.com/users/285475/screenshots/2083086/dribbble_1.gif);
            min-height: 400px;
            background-position: center;
            margin: 40px 0 0 180px;
        }

        .four_zero_four_bg h1 {
            font-size: 80px;
        }

        .four_zero_four_bg h3 {
            font-size: 80px;
        }

        .link_404 {
            color: #fff !important;
            border-radius: 18px;
            padding: 10px 20px;
            background: #39ac31;
            margin: 20px 0;
            text-decoration: none; /* Remove underline by default */
            display: inline-block;
            text-underline-offset: 0;
        }

        .link_404:hover {
            text-decoration: none; /* Remove underline on hover */
        }

        .contant_box_404 {
            margin-top: -40px;
            margin-left: 180px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth/resources/views/errors/404.blade.php ENDPATH**/ ?>