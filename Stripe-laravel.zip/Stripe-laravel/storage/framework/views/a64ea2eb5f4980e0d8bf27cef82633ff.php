<?php $__env->startComponent('mail::message'); ?>
# Payment Successful

Your payment has been successfully processed.

**Order ID:** <?php echo e($order->id); ?>

**Total Amount:** $<?php echo e($order->total); ?>

**Payment Method:** Credit/Debit Card

Thank you for your purchase! Your order is being processed, and we will notify you once it's shipped.

Thanks,
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth (copy)/resources/views/emails/orders/payment_success.blade.php ENDPATH**/ ?>