<html>
    <body>


<script src="https://js.stripe.com/v3/"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const stripe = Stripe('your-publishable-key'); // Replace with your Stripe public key

    document.getElementById('paymentForm').addEventListener('submit', function(event) {
        event.preventDefault();
        const paymentData = {
            payment_method: 'card', // Update based on user selection (card/UPI)
            payment_method_id: document.getElementById('payment_method_id').value,
            totalprice: document.getElementById('totalprice').value,
        };

        fetch('/process-payment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
            },
            body: JSON.stringify(paymentData),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                stripe.confirmCardPayment(data.client_secret, {
                    payment_method: {
                        card: document.getElementById('cardElement'), // Replace with your card element ID
                        billing_details: {
                            name: document.getElementById('cardholderName').value,
                        },
                    },
                }).then(function(result) {
                    if (result.error) {
                        console.error(result.error.message);
                        alert('Payment failed: ' + result.error.message);
                    } else {
                        if (result.paymentIntent.status === 'succeeded') {
                            window.location.href = data.redirect_url; // Redirect after success
                        }
                    }
                });
            } else {
                alert('Payment failed: ' + data.error);
            }
        });
    });
});
</script>
</body>
</html>
