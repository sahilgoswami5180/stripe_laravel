<?php

namespace App\Http\Controllers;

use App\Models\Combo;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DeletedComboController extends Controller
{
    /**
     * Show the list of deleted combos (soft deleted).
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // Ensure the user is authenticated
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login')->with('error', 'You must be logged in to view deleted combos.');
        }

        // Get all soft-deleted combos
        $deletedCombos = Combo::onlyTrashed()->paginate(10);  // You can adjust pagination as needed

        // Return the view with deleted combos
        return view('combos.deleted', compact('deletedCombos'));
    }

    /**
     * Restore the specified soft-deleted combo.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function restore($id)
    {
        // Ensure the user is authenticated
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login')->with('error', 'You must be logged in to restore combos.');
        }

        // Find the soft-deleted combo by its ID
        $combo = Combo::withTrashed()->findOrFail($id);

        // Restore the combo
        $combo->restore();

        // Redirect back with success message
        return redirect()->route('deleted-combos.index')->with('success', 'Combo restored successfully!');
    }

    /**
     * Force delete a combo permanently.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function forceDelete($id)
    {
        // Ensure the user is authenticated
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login')->with('error', 'You must be logged in to permanently delete combos.');
        }

        // Find the soft-deleted combo by its ID
        $combo = Combo::onlyTrashed()->findOrFail($id);

        // Force delete the combo permanently
        $combo->forceDelete();

        // Redirect back with success message
        return redirect()->route('deleted-combos.index')->with('success', 'Combo permanently deleted.');
    }
}
