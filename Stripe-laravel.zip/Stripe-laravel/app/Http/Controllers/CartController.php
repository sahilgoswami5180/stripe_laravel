<?php

namespace App\Http\Controllers;

use App\Models\CartItem;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;


class CartController extends Controller
{
    // Display the cart page
    public function index()
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Get the current user's cart items
        $cartItems = CartItem::where('user_id', Auth::id())->get();

        // Return the cart page
        return view('user.cart', compact('cartItems'));
    }

    // Add a product to the cart
    public function add(Product $product, Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }
        // If the user is logged in, store the cart in the database
        if (Auth::check()) {
            // Check if the product is already in the user's cart
            $cartItem = CartItem::where('user_id', Auth::id())
                ->where('product_id', $product->id)
                ->first();

            if ($cartItem) {
                // If the product is already in the cart, increase the quantity
                $cartItem->quantity += 1;
                $cartItem->save();
            } else {
                // If the product is not in the cart, create a new cart item
                CartItem::create([
                    'user_id' => Auth::id(),
                    'product_id' => $product->id,
                    'quantity' => 1, // Start with quantity 1 for the new product
                ]);
            }

            // Get updated cart items for the user
            $cartItems = CartItem::where('user_id', Auth::id())->get();

            // Check if the request is AJAX
            if ($request->ajax()) {
                // Return the updated cart as a JSON response
                return response()->json([
                    'success' => true,
                    'message' => 'Product added to cart.',
                    'cartItems' => $cartItems,
                    'total' => number_format($cartItems->sum(fn($item) => $item->product->price * $item->quantity), 2),
                ]);
            }

            // Redirect back to the cart page if not AJAX request
            return redirect()->back()->with('success', 'Product added to cart!');
        }

        // If the user is not logged in, use the session-based cart
        $cart = session('cart', []);

        if (isset($cart[$product->id])) {
            // If product is in the cart, increase the quantity
            $cart[$product->id]['quantity']++;
        } else {
            // If product is not in the cart, add it
            $cart[$product->id] = [
                'product_id' => $product->id,
                'quantity' => 1,
                'name' => $product->name,
                'price' => $product->price,
                'image' => $product->image,
            ];
        }

        // Update session
        session()->put('cart', $cart);

        // Check if the request is AJAX
        if ($request->ajax()) {
            // Return the updated cart as a JSON response
            return response()->json([
                'success' => true,
                'message' => 'Product added to cart.',
                'cartItems' => $cart,
                'total' => number_format(array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart)), 2),
            ]);
        }

        return redirect()->back()->with('success', 'Product added to cart!');
    }

    // Remove an item from the cart
    public function remove(CartItem $cartItem, Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }

        // Ensure the item belongs to the authenticated user
        if ($cartItem->user_id === Auth::id()) {
            $cartItem->delete(); // Delete the cart item
        }

        // After removing the item, get the updated cart items for the user
        $cartItems = CartItem::where('user_id', Auth::id())->get();

        // Calculate the total price for the updated cart
        $total = number_format($cartItems->sum(fn($item) => $item->product->price * $item->quantity), 2);

        // Check if the request is AJAX
        if ($request->ajax()) {
            // Return the updated cart as a JSON response
            return response()->json([
                'success' => true,
                'message' => 'Item removed from cart.',
                'cartItems' => $cartItems,  // Return updated cart items
                'total' => $total,  // Return the new total price
                'itemCount' => $cartItems->count()  // Optional: Return the number of items in the cart
            ]);
        }

        // Redirect back to the cart page with a success message
        return redirect()->back()->with('success', 'Product removed from cart!');
    }



    // Update the quantity of a cart item
    public function updateQuantity(CartItem $cartItem, Request $request)
    {
        if (!Auth::check() || Auth::user()->role !== 'user') {
            return redirect()->route('login'); // Redirect to login if not authenticated or not an admin
        }
        // Ensure the item belongs to the authenticated user
        if ($cartItem->user_id === Auth::id()) {
            // Validate quantity input, ensuring it's an integer and at least 1
            $request->validate([
                'quantity' => 'required|integer|min:1', // Ensure quantity is a valid integer and at least 1
            ]);

            // Get the new quantity from the request
            $quantity = $request->input('quantity');

            // Update the cart item with the new quantity
            $cartItem->quantity = $quantity;
            $cartItem->save();
        }

        // After updating the quantity, get the updated cart items for the user
        $cartItems = CartItem::where('user_id', Auth::id())->get();

        // Check if the request is AJAX
        if ($request->ajax()) {
            // Return the updated cart as a JSON response
            return response()->json([
                'success' => true,
                'message' => 'Cart item quantity updated.',
                'cartItems' => $cartItems,
                'total' => number_format($cartItems->sum(fn($item) => $item->product->price * $item->quantity), 2),
            ]);
        }

        // Redirect back to the cart page if it's not an AJAX request
        return redirect()->back()->with('success', 'Cart updated successfully!');
    }
}
