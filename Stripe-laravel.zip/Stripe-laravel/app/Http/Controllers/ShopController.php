<?php

namespace App\Http\Controllers;

use App\Models\CartItem;
use App\Models\Category;
use App\Models\Combo;
use App\Models\Product;
use Illuminate\Support\Facades\Request;

class ShopController extends Controller
{

    public function index(Request $request)
    {
        // Validate the incoming request
        $validated = $request->validate([
            'category_id' => 'nullable|array',
            'category_id.*' => 'exists:categories,id', // Ensure each category_id exists in the categories table
            'subcategory_id' => 'nullable|array',
            'subcategory_id.*' => 'exists:subcategories,id', // Ensure each subcategory_id exists in the subcategories table
            'price_max' => 'nullable|numeric|min:0|max:1000000', // Price should be a number between 0 and 1,000,000
            'sort' => 'nullable|in:relevant,popular,new', // Only allow certain values for sort
            'search' => 'nullable|string|max:255', // Ensure search is a string and not too long
        ]);

        // Get categories for filtering
        $categories = Category::all();

        // Start with fetching all active products
        $products = Product::where('status', 'active');

        // Apply category filter if category or subcategory is selected
        $categoryIds = $request->category_id ?? [];
        if (!empty($categoryIds)) {
            // If 'All Categories' is selected, we don't filter by category
            if (in_array('all', $categoryIds)) {
                $categoryIds = Category::pluck('id')->toArray(); // Get all category IDs
            }

            // Apply the category filter if specific categories are selected
            if (count($categoryIds) > 0) {
                $products = $products->whereIn('category_id', $categoryIds);
            }
        }

        // Apply subcategory filter if selected
        if ($request->has('subcategory_id') && !empty($request->subcategory_id)) {
            $subcategoryIds = $request->subcategory_id;
            $products = $products->whereIn('subcategory_id', $subcategoryIds);
        }

        // Apply price filter if a max price is selected
        if ($request->has('price_max') && is_numeric($request->price_max)) {
            $priceMax = (float) $request->price_max;
            if ($priceMax > 0) {
                $products = $products->where('price', '<=', $priceMax);
            }
        }

        // Apply search filter if there's a search query
        if ($request->has('search') && $request->search != '') {
            $products = $products->where('name', 'like', '%' . $request->search . '%');
        }

        // Apply sorting based on user selection
        if ($request->has('sort') && $request->sort !== '') {
            switch ($request->sort) {
                case 'popular':
                    // Sort by popularity (assuming 'orders_count' is a metric for popularity)
                    $products = $products->withCount('orders')  // Count orders related to each product
                        ->orderByDesc('orders_count');  // Order by order count (popularity)
                    break;

                case 'new':
                    // Sort by latest added (based on created_at or similar field)
                    $products = $products->orderByDesc('created_at');  // Sort by creation date (latest first)
                    break;

                case 'relevant':
                    // Default sorting (could be name, or another criteria you consider "relevant")
                    $products = $products->orderBy('name');  // Default sorting by name
                    break;
            }
        } else {
            // Default sort if no sort option is provided (for example, by creation date)
            $products = $products->orderByDesc('created_at');
        }

        // Fetch the filtered and sorted products with pagination
        $products = $products->paginate(10);  // Paginate products (10 per page)

        // Get cart items from session (or database if persistent cart)
        $cartItems = CartItem::where('user_id', auth()->id())->get()->keyBy('product_id');

        // Get wishlist from session
        $wishlist = session()->get('wishlist', []);

        // Fetch combos for display with filtering and pagination
        $combos = Combo::with(['category', 'subcategory', 'products']);

        // Apply filtering to combos based on category and subcategory
        if ($request->has('category_id') && !empty($categoryIds)) {
            if (in_array('all', $categoryIds)) {
                $combos = $combos->whereIn('category_id', Category::pluck('id')->toArray());
            } else {
                $combos = $combos->whereIn('category_id', $categoryIds);
            }
        }

        if ($request->has('subcategory_id') && !empty($request->subcategory_id)) {
            $combos = $combos->whereIn('subcategory_id', $request->subcategory_id);
        }

        // Apply sorting to combos (if applicable)
        if ($request->has('sort') && $request->sort !== '') {
            switch ($request->sort) {
                case 'popular':
                    // Example sorting for combos by number of orders (or another field)
                    $combos = $combos->withCount('orders')  // Count orders related to each combo
                        ->orderByDesc('orders_count');  // Order by order count (popularity)
                    break;

                case 'new':
                    $combos = $combos->orderByDesc('created_at');  // Sort by creation date (latest first)
                    break;

                case 'relevant':
                    $combos = $combos->orderBy('name');  // Default sorting by name
                    break;
            }
        } else {
            $combos = $combos->orderByDesc('created_at');  // Default sort by creation date
        }

        // Paginate combos (5 per page for now)
        $combos = $combos->paginate(5);

        // Return view with products, categories, cart items, wishlist, and combos
        return view('shop.index', compact('products', 'categories', 'cartItems', 'wishlist', 'combos'));
    }

    public function seemorecombos()
    {
        $combos = Combo::all();

        return view('shop.combos', compact('combos'));
    }
}