<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Combo;
use App\Models\ContactUs;
use App\Models\Order;
use App\Models\Product;
use App\Models\Subcategory;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        // Check if user is authenticated
        if (!Auth::check()) {
            return redirect()->route('home'); // Redirect to home route if not authenticated
        }

        // Check if user has 'admin' role
        if (Auth::user()->role !== 'admin') {
            return redirect()->route('home')->with('error', 'You do not have permission to access this page.');
        }

        // Fetch active categories
        $activeCategories = Category::all(); // Soft deletes are handled automatically if the model uses SoftDeletes
        $activeSubcategories = Subcategory::all();  // For soft deletes
        $combos = Combo::all();
        $Users = User::all();
        $activeorders = Order::all();
        // Fetch active products
        $activeProducts = Product::where('status', 'active')->get();
        $contactUsSubmissions = ContactUs::all();
        $unreadCount = ContactUs::where('read', false)->count();

        // Return the view with the fetched data
        return view('dashboard', compact('activeCategories', 'activeorders', 'combos', 'Users', 'activeSubcategories', 'activeProducts', 'contactUsSubmissions', 'unreadCount'));
    }

    public function dashboard()
    {
        // Fetch all contact submissions
        $contactUsSubmissions = ContactUs::all();
        $unreadCount = ContactUs::where('read', false)->count();

        return view('dashboard', compact('contactUsSubmissions', 'unreadCount'));
    }
    // Mark the contact submission as read
    public function markAsRead($id)
    {
        $contactUs = ContactUs::findOrFail($id);
        $contactUs->update(['read' => true]);

        return redirect()->route('dashboard')->with('success', 'Notification marked as read.');
    }
}
