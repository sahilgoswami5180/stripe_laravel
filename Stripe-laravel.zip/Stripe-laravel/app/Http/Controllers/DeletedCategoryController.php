<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DeletedCategoryController extends Controller
{
    /**
     * Show the list of deleted categories.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login')->with('error', 'You must be logged in to view deleted categories.');
        }



        // Get all soft-deleted categories
        $deletedCategories = Category::onlyTrashed()->get();

        return view('categories.deleted', compact('deletedCategories'));
    }

    /**
     * Restore the specified soft-deleted category.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function restore($id)
    {
        // Ensure the user is authenticated
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login')->with('error', 'You must be logged in to restore categories.');
        }

        // Find the soft-deleted category by its ID
        $category = Category::withTrashed()->findOrFail($id);

        // Restore the category
        $category->restore();

        // Redirect back with success message
        return redirect()->route('deleted-categories.index')->with('success', 'Category restored successfully!');
    }

    /**
     * Force delete a category permanently.
     *
     * @param  int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function forceDelete($id)
    {
        // Ensure the user is authenticated
        if (!Auth::check() || Auth::user()->role !== 'admin') {
            return redirect()->route('login')->with('error', 'You must be logged in to permanently delete categories.');
        }

        // Find the soft-deleted category by its ID
        $category = Category::onlyTrashed()->findOrFail($id);

        // Force delete the category permanently
        $category->forceDelete();

        // Redirect back with success message
        return redirect()->route('deleted-categories.index')->with('success', 'Category permanently deleted.');
    }
}
