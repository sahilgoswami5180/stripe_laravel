<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Password;
use App\Models\User;

class PasswordResetController extends Controller
{
    /**
     * Show the forgot password form.
     *
     * @return \Illuminate\View\View
     */
    public function showForgotPasswordForm()
    {
        return view('auth.forgot-password');
    }

    /**
     * Handle sending the password reset link.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function sendResetLink(Request $request)
    {
        // Validate the email input
        $validated = $request->validate([
            'email' => 'required|email',
        ]);

        // Check if the user exists
        $user = User::where('email', $validated['email'])->first();

        if (!$user) {
            return back()->withErrors(['email' => 'No account found with this email address.']);
        }

        // Attempt to send the password reset link
        $status = Password::sendResetLink($validated);

        // Redirect based on the status
        if ($status === Password::RESET_LINK_SENT) {
            return redirect()->back()
                ->with('success', 'Password reset link sent successfully. Check your email.');
        }

        return back()->withErrors(['email' => 'Unable to send reset link. Please try again later.']);
    }

    /**
     * Show the password reset form.
     *
     * @param string $token
     * @return \Illuminate\View\View
     */
    public function showResetForm($token)
    {
        return view('auth.reset-password', ['token' => $token]);
    }



    /**
     * Handle the password reset request.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function reset(Request $request)
    {
        // Add the token from the URL to the validation array
        $request->merge(['token' => $request->route('token')]);

        $validated = $request->validate([
            'email' => 'required|email',
            'password' => 'required|confirmed|min:8',
            'token' => '', // The token is fetched automatically from the route
        ]);

        $status = Password::reset(
            $validated,
            function (User $user) use ($validated) {
                $user->forceFill([
                    'password' => bcrypt($validated['password']),
                ])->save();
            }
        );

        if ($status === Password::PASSWORD_RESET) {
            return redirect()->route('login')
                ->with('success', 'Password reset successfully. You can now log in.');
        }

        return back()->withErrors(['email' => 'Failed to reset the password. Please try again later.']);
    }
}
