<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    // Define the table name (if it's different from the plural form of the model name)
    protected $table = 'orders';

    // Define the fillable fields (including all necessary fields from both versions)
    protected $fillable = [
        'user_id',
        'total',
        'status',
        'product_id', // Add product_id to fillable
        'order_items',
        'order_images',
        'order_quantities',
        'order_prices',
        'address', // Add the address field here from the first model
    ];

    // Define relationships with other models

    // Relationship with User model
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // Relationship with the Product model (assuming an order belongs to one product, you can change to many if needed)
    public function product()
    {
        return $this->belongsTo(Product::class); // One-to-many relationship, if each order belongs to a single product
    }

    // Many-to-many relationship with the Product model through the pivot table 'order_product' (optional, based on your database schema)
    public function products()
    {
        return $this->belongsToMany(Product::class, 'order_product'); // Assuming a pivot table for many-to-many relationship
    }

    // Relationship with OrderItem model (assuming each order can have multiple items)
    public function orderItems()
    {
        return $this->hasMany(OrderItem::class); // Foreign key: order_id
    }

    // Relationship with CartItem model (optional, based on your needs)
    public function cartItems()
    {
        return $this->hasMany(CartItem::class); // Related to cart items
    }

    // Relationship with Category model (optional, if an order belongs to a category)
    public function category()
    {
        return $this->belongsTo(Category::class); // If an Order belongs to a Category
    }
}