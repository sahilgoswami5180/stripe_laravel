<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Job extends Model
{
    // Use SoftDeletes trait to enable soft delete functionality
    use SoftDeletes;

    /**
     * The name of the table associated with the model.
     *
     * @var string
     */
    protected $table = 'jobs';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'queue',
        'payload',
        'attempts',
        'reserved_at',
        'available_at',
        'created_at',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'reserved_at' => 'datetime',
        'available_at' => 'datetime',
        'created_at' => 'datetime',
    ];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = [
        'deleted_at', // Soft delete column
        'reserved_at', // These columns are dates, so we cast them
        'available_at',
        'created_at',
    ];

    /**
     * Get the job's status (e.g., failed or completed) based on its attempts.
     *
     * @return string
     */
    public function getStatusAttribute()
    {
        if ($this->attempts >= 3) {
            return 'failed';
        }

        return 'pending';
    }

    /**
     * Scope a query to only include jobs that are pending.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopePending($query)
    {
        return $query->where('attempts', '<', 3)->whereNull('deleted_at');
    }

    /**
     * Scope a query to include jobs that have been soft-deleted.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeTrashedJobs($query)
    {
        return $query->onlyTrashed(); // Retrieves only soft-deleted jobs
    }

    /**
     * Restore a soft-deleted job.
     *
     * @return void
     */
    public function restoreJob()
    {
        $this->restore(); // This restores the soft-deleted job
    }

    /**
     * Force delete a job.
     *
     * @return void
     */
    public function forceDeleteJob()
    {
        $this->forceDelete(); // This permanently deletes the job from the database
    }

    /**
     * Get the time until the job is available.
     *
     * @return \Carbon\Carbon
     */
    public function getTimeUntilAvailable()
    {
        return \Carbon\Carbon::createFromTimestamp($this->available_at)->diffForHumans();
    }

    /**
     * Get the human-readable time since the job was created.
     *
     * @return string
     */
    public function getTimeSinceCreated()
    {
        return $this->created_at->diffForHumans();
    }

    /**
     * Example relationship to another model (if necessary)
     * For example, if a Job belongs to a User:
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);  // Adjust the model name as needed
    }

    /**
     * Example relationship to a JobBatch model (if necessary)
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function jobBatch()
    {
        return $this->belongsTo(JobBatch::class);  // Adjust the model name as needed
    }

    /**
     * Custom function to retry the job (for example, if the job failed).
     *
     * @return void
     */
    public function retry()
    {
        // Logic to retry a job could go here. For example:
        $this->attempts = 0;
        $this->reserved_at = now()->timestamp;
        $this->save();
    }
}
