<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class Category extends Model
{
    use HasFactory, SoftDeletes; // Enable SoftDeletes

    // Fillable fields for mass assignment
    protected $fillable = ['name', 'description', 'image'];

    // Relationship: A category has many products
    public function products()
    {
        return $this->hasMany(Product::class);
    }

    // Relationship: A category has many subcategories
    public function subcategories()
    {
        return $this->hasMany(Subcategory::class);
    }

    public function combos()
    {
        return $this->hasMany(Combo::class);
    }
    // Boot method to handle cascading soft-deletes and restorations
    protected static function boot()
    {
        parent::boot();

        // Automatically handle cascading deletes
        static::deleting(function ($category) {
            if ($category->isForceDeleting()) {
                // Hard delete related products and subcategories when the category is permanently deleted
                $category->products()->forceDelete();
                $category->subcategories()->forceDelete();
            } else {
                // Soft delete related products and subcategories when the category is soft deleted
                $category->products()->delete();
                $category->subcategories()->delete();
            }
        });

        // Automatically handle cascading restores
        static::restoring(function ($category) {
            // Restore related products and subcategories when the category is restored
            $category->products()->withTrashed()->restore();
            $category->subcategories()->withTrashed()->restore();
        });
    }
}
