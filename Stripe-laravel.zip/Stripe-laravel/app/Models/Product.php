<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes; // For soft delete functionality

class Product extends Model
{
    use HasFactory, SoftDeletes; // Add SoftDeletes to the model

    // Fillable fields for mass assignment
    protected $fillable = [
        'name',
        'description',
        'price',
        'category_id',
        'subcategory_id',  // Add 'subcategory_id' to fillable for mass assignment
        'images',  // Changed from 'image' to 'images' to store multiple images
        'status', // Add 'status' to fillable
    ];

    // Define possible statuses for the product
    const STATUS_ACTIVE = 'active';
    const STATUS_INACTIVE = 'inactive';

    /**
     * Get the available statuses.
     *
     * @return array
     */
    public static function getStatuses()
    {
        return [
            self::STATUS_ACTIVE,
            self::STATUS_INACTIVE,
        ];
    }

    /**
     * Define the relationship between Product and Category.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function category()
    {
        return $this->belongsTo(Category::class); // A product belongs to a category
    }

    /**
     * Define the relationship between Product and Subcategory.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function subcategory()
    {
        return $this->belongsTo(Subcategory::class); // A product belongs to a subcategory
    }

    /**
     * Define the relationship between Product and OrderItem.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function combos()
    {
        return $this->belongsToMany(Combo::class, 'combo_product');
    }
    /**
     * Automatically cast the 'images' attribute to an array.
     *
     * @var array
     */
    protected $casts = [
        'images' => 'array',  // Automatically convert the comma-separated string into an array
    ];

    /**
     * Get the full URLs for the product images.
     *
     * @return array
     */
    public function getImageUrlsAttribute()
    {
        if (is_array($this->images)) {
            // If 'images' is an array, return the full URLs of images stored in public storage
            return array_map(function ($image) {
                return asset('storage/' . $image);
            }, $this->images);
        }

        // If 'images' is not an array (e.g., a string), handle accordingly
        return [];
    }


    /**
     * Add the image URLs to the product data when retrieving it.
     *
     * @return array
     */
    public function toArray()
    {
        $attributes = parent::toArray();

        // Add the image URLs to the product data
        $attributes['image_urls'] = $this->getImageUrlsAttribute();

        return $attributes;
    }
}
