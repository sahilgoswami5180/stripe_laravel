<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SupportRequest extends Model
{
    use HasFactory;

    // Define the table associated with the model
    protected $table = 'support_requests';

    // Specify the columns that are mass assignable
    protected $fillable = [
        'user_id',
        'message',
        'status',
    ];

    // Define the relationship between the SupportRequest and User models
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
