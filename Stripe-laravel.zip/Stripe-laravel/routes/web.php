<?php

use App\Http\Controllers\AccountController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ChangePasswordController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\ComboController;
use App\Http\Controllers\ContactUsController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DeletedCategoryController;
use App\Http\Controllers\DeletedComboController;
use App\Http\Controllers\DeletedProductController;
use App\Http\Controllers\DeletedSubcategoryController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PasswordResetController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SubcategoryController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\UserDetailsController;
use App\Models\ContactUs;
use Illuminate\Support\Facades\Route;

// dd('sd');


// Routes outside auth middleware
Route::get('/', [AuthController::class, 'showLoginForm'])->name('home'); // Home route
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');

// Registration routes
Route::get('register', [AuthController::class, 'showRegisterForm'])->name('register.form');
Route::post('register', [AuthController::class, 'register'])->name('register');
Route::get('/email/verify/{token}', [AuthController::class, 'verifyEmail'])->name('auth.verify-email');
Route::get('/check-user-existence', [AuthController::class, 'checkUserExistence']);

// Login and logout routes
Route::post('login', [AuthController::class, 'login'])->name('login');
Route::post('logout', [AuthController::class, 'logout'])->name('logout');


// Password reset routes
Route::get('forgot-password', [PasswordResetController::class, 'showForgotPasswordForm'])->name('forgot.password');
Route::post('forgot-password', [PasswordResetController::class, 'sendResetLink'])->name('password.email');
Route::get('password/reset/{token}', [PasswordResetController::class, 'showResetForm'])->name('password.reset');
Route::post('password/reset', [PasswordResetController::class, 'reset'])->name('password.update');

// Routes inside auth middleware

// OTP Verification routes
Route::get('otp/verify', [AuthController::class, 'showOtpVerifyForm'])->name('auth.verify-otp');
Route::post('otp/verify', [AuthController::class, 'verifyOtp'])->name('otp.verify');
Route::post('otp/resend', [AuthController::class, 'resendOtp'])->name('otp.resend');

// Password reset routes
Route::get('password/reset', [AuthController::class, 'showResetPasswordForm'])->name('auth.reset-password.page');
Route::post('password/reset', [AuthController::class, 'resetPassword'])->name('auth.reset-password');
Route::resource('categories', CategoryController::class);

Route::middleware(['auth'])->group(function () {
    // Dashboard and user-related routes
    Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::get('index', [UserController::class, 'index'])->name('user.index');
    Route::get('shop', [UserController::class, 'shop'])->name('shop.index');

    // Category routes
    Route::get('/category', [CategoryController::class, 'index'])->name('categories.index');
    Route::get('/category/{category}', [CategoryController::class, 'view'])->name('categories.view');




    // Restore a deleted category
    Route::post('/categories/{id}/restore', [CategoryController::class, 'restore'])->name('categories.restore');
    // Permanently delete a category
    Route::delete('/categories/{id}/destroy', [CategoryController::class, 'destroy'])->name('categories.destroy');

    // Product routes
    Route::resource('products', ProductController::class);
    Route::put('/products/{product}', [ProductController::class, 'update'])->name('products.update');

    Route::post('products/{product}/change-status', [ProductController::class, 'updateStatus'])->name('products.change-status');
    // Route::put('products/{product}/edit', [ProductController::class, 'update'])->name('products.edit');
    Route::delete('products/{product}/delete', [ProductController::class, 'destroy'])->name('products.delete');
    Route::post('categories/{category}/products/change-status1', [ProductController::class, 'updateStatus1'])->name('categories.products.change-status');
    Route::get('/products/{id}/edit', [ProductController::class, 'edit'])->name('products.edit');

    Route::post('/products/{id}/upload-images', [ProductController::class, 'uploadImages'])->name('products.upload-images');
    Route::delete('/products/{product}/remove-image/{image}', [ProductController::class, 'removeImage'])->name('products.remove-image');
    Route::get('products/{product}/edit_image', [ProductController::class, 'editImage'])->name('products.image-edit');

    //combos routes

    Route::get('/combos', [ComboController::class, 'index'])->name('combos.index'); // List all combos
    Route::get('/combos/create', [ComboController::class, 'create'])->name('combos.create'); // Show create form
    Route::post('/combos', [ComboController::class, 'store'])->name('combos.store'); // Store new combo
    Route::get('/combos/{combo}', [ComboController::class, 'show'])->name('combos.show'); // Show single combo details
    Route::get('/combos/{combo}/edit', [ComboController::class, 'edit'])->name('combos.edit'); // Show edit form
    Route::put('/combos/{combo}', [ComboController::class, 'update'])->name('combos.update'); // Update combo
    Route::delete('/combos/{combo}', [ComboController::class, 'destroy'])->name('combos.destroy'); // Soft delete combo
    Route::get('/get-subcategories/{categoryId}', [CategoryController::class, 'getSubcategories']);

    // Soft delete & restore combo
    Route::get('deleted-combos', [DeletedComboController::class, 'index'])->name('deleted-combos.index'); // Show deleted combos
    Route::post('combos/{combo}/restore', [DeletedComboController::class, 'restore'])->name('combos.restore'); // Restore deleted combo
    Route::delete('combos/{combo}/force-delete', [DeletedComboController::class, 'forceDelete'])->name('combos.forceDelete'); // Permanently delete combo
    // Deleted categories routes
    Route::get('deleted-categories', [DeletedCategoryController::class, 'index'])->name('deleted-categories.index');
    Route::post('deleted-categories/{id}/restore', [DeletedCategoryController::class, 'restore'])->name('deleted-categories.restore');
    Route::delete('deleted-categories/{id}/force-delete', [DeletedCategoryController::class, 'forceDelete'])->name('deleted-categories.force-delete');

    // Deleted products routes
    Route::get('deleted-products', [DeletedProductController::class, 'index'])->name('deleted-products.index');
    Route::post('deleted-products/{id}/restore', [DeletedProductController::class, 'restore'])->name('deleted-products.restore');
    Route::delete('deleted-products/{id}/force-delete', [DeletedProductController::class, 'forceDelete'])->name('deleted-products.force-delete');

    // Product card view and QR code
    Route::get('products/card', [ProductController::class, 'card'])->name('products.card-view');
    Route::get('product/{productId}/qr-code', [ProductController::class, 'generateProductQrCode'])->name('products.qr-code');
    Route::get('/products/export/pdf', [ProductController::class, 'exportToPdf'])->name('products.export.pdf');
    Route::get('/products/export/csv', [ProductController::class, 'exportToCsv'])->name('products.export.csv');
    Route::get('/get-subcategories/{categoryId}', [ProductController::class, 'getSubcategories']);

    // User account and cart routes
    Route::get('/account', [AccountController::class, 'index'])->name('account');

    // Cart Routes
    Route::get('/cart', [CartController::class, 'index'])->name('user.cart');  // View the cart
    Route::post('cart/add/{product}', [CartController::class, 'add'])->name('cart.add');
    Route::delete('/cart/{cartItem}', [CartController::class, 'remove'])->name('cart.remove');
    Route::patch('/cart/{cartItem}', [CartController::class, 'updateQuantity'])->name('cart.updateQuantity');  // Update quantity in cart


    Route::get('/checkout', [CheckoutController::class, 'index'])->name('user.checkout');
    Route::post('/checkout/cod', [CheckoutController::class, 'codCheckout'])->name('checkout.cod');
    Route::post('/razorpay/order/create', [CheckoutController::class, 'createRazorpayOrder'])->name('razorpay.order.create');
    Route::post('/checkout/process', [CheckoutController::class, 'process'])->name('checkout.process');
    Route::get('/checkout/success', [CheckoutController::class, 'success'])->name('checkout.success');
    Route::get('/checkout/cancel', [CheckoutController::class, 'cancel'])->name('checkout.cancel');

    Route::get('/categories/{category}/products', [CategoryController::class, 'viewProducts'])->name('categories.products');
    Route::get('/categories/{category}/subcategories', [CategoryController::class, 'viewSubcategories'])->name('categories.viewSubcategories');
    Route::get('/category/{category}/products', [UserController::class, 'categorywiseshow'])->name('shop.categorywiseproduct');

    Route::get('subcategories', [SubcategoryController::class, 'index'])->name('subcategories.index');
    Route::get('subcategories/create', [SubcategoryController::class, 'create'])->name('subcategories.create');
    Route::post('subcategories', [SubcategoryController::class, 'store'])->name('subcategories.store');
    Route::get('subcategories/{id}', [SubcategoryController::class, 'show'])->name('subcategories.show');
    Route::get('subcategories/{id}/edit', [SubcategoryController::class, 'edit'])->name('subcategories.edit');
    Route::put('subcategories/{id}', [SubcategoryController::class, 'update'])->name('subcategories.update');
    Route::delete('subcategories/{id}', [SubcategoryController::class, 'destroy'])->name('subcategories.destroy');
    Route::get('deleted-subcategories', [DeletedSubcategoryController::class, 'index'])->name('subcategories.deleted');
    Route::post('deleted-subcategories/{id}/restore', [DeletedSubcategoryController::class, 'restore'])->name('subcategories.restore');
    Route::delete('deleted-subcategories/{id}/force-delete', [DeletedSubcategoryController::class, 'forceDelete'])->name('subcategories.force-delete');
    Route::get('subcategories/export-pdf', [SubcategoryController::class, 'exportToPdf'])->name('subcategories.exportToPdf');
    Route::get('subcategories/{subcategory}', [SubcategoryController::class, 'show'])->name('subcategories.show');

    // Route for displaying products of a subcategory
    Route::get('subcategories/{id}/products', [SubcategoryController::class, 'viewProducts'])->name('subcategories.viewProducts');

    Route::get('product/{id}', [UserController::class, 'showproducts'])->name('shop.product_details');
    Route::get('shop/combos', [UserController::class, 'seemorecombos'])->name('shop.combos');
    Route::get('combo/{id}', [UserController::class, 'showcombos'])->name('shop.combo_details');
    Route::post('/cart/add/{combo}', [CartController::class, 'add'])->name('cart.add');

    Route::get('/search', [UserController::class, 'index'])->name('user.search');
    Route::post('/delete-account', [UserController::class, 'deleteAccount'])->name('delete.account');


    // Change password routes
    Route::get('/change-password', [ChangePasswordController::class, 'showChangePasswordForm'])->name('change-password.form');
    Route::post('/change-password', [ChangePasswordController::class, 'updatePassword'])->name('change-password.update');

    // Change password routes for user
    Route::get('/user/change-password', [ChangePasswordController::class, 'showuserChangePasswordForm'])->name('userchange-password.form');
    Route::post('/user/change-password', [ChangePasswordController::class, 'updatePassword'])->name('change-password.update');
    // User profile routes
    Route::get('/profile', [AuthController::class, 'show'])->name('profile');
    Route::get('/myprofile', [AuthController::class, 'userprofileshow'])->name('userprofile');


    // user_details routes

    // Resourceful routes for user details (index, create, store, show, edit, update, destroy)
    Route::resource('user_details', UserDetailsController::class);
    Route::get('user_details', [UserDetailsController::class, 'index'])->name('user_details.index');
    // Soft Delete, Restore, and Force Delete routes
    // These are custom routes not included by default in a resource controller
    Route::post('user_details/{id}/softdelete', [UserDetailsController::class, 'softDelete'])->name('user_details.softDelete');
    Route::post('user_details/{id}/restore', [UserDetailsController::class, 'restore'])->name('user_details.restore');
    Route::delete('user_details/{id}/forceDelete', [UserDetailsController::class, 'forceDelete'])->name('user_details.forceDelete');
    Route::patch('/users/{user}/toggle-role', [UserController::class, 'toggleRole'])->name('user.toggleRole');

    Route::get('orders', [UserController::class, 'showOrders'])->name('user.orders');
    Route::get('/orders/{order}', [UserController::class, 'showOrderDetails'])->name('user.myorder-details');

    // Wishlist Section
    Route::get('/wishlist', [UserController::class, 'showWishlist'])->name('shop.wishlist');
    // Wishlist Routes
    // Add product to wishlist (POST)
    Route::post('wishlist/add/{product}', [UserController::class, 'addWishlist'])->name('wishlist.add');

    // Remove product from wishlist (DELETE)
    Route::delete('wishlist/remove/{product}', [UserController::class, 'removeWishlist'])->name('wishlist.remove');



    // Support Section
    // Display support page (GET request)
    Route::get('/profile/support', [UserController::class, 'showSupport'])->name('user.support');

    // Handle form submission (POST request)
    Route::post('/profile/support', [UserController::class, 'storeSupport'])->name('user.support.store');
    Route::get('/About-us', [UserController::class, 'Aboutus'])->name('user.about-us');
    Route::get('/Blog', [UserController::class, 'Blog'])->name('user.blog');


    // FAQ Section
    Route::get('/profile/faq', [UserController::class, 'showFAQ'])->name('user.faq');

    Route::put('/profile/image', [AuthController::class, 'updateImage'])->name('profile.update.image');
    Route::put('/profile/userimage', [AuthController::class, 'updateuserImage'])->name('profile.update.userimage');

    Route::resource('order', OrderController::class);
    Route::post('order/{order}/edit', [OrderController::class, 'update'])->name('order.edit');
    Route::get('/contact-us', [ContactUsController::class, 'create'])->name('user.contact-us');
    Route::post('/contact-us', [ContactUsController::class, 'store']);
    Route::get('/dashboard/contact-msg', [DashboardController::class, 'dashboard'])->name('dashboard.contact-msg');
    Route::post('/contact-msg/{id}/read', [ContactUsController::class, 'markAsRead'])->name('contact-msg.mark-as-read');
    Route::post('/contact-msg/mark-all-as-read', [NotificationController::class, 'markAllAsRead'])->name('contact-msg.mark-all-as-read');
    Route::delete('/contact-msg/clear-all', [NotificationController::class, 'clearAll'])->name('contact-msg.clear-all');
    Route::delete('/contact-msg/delete-selected', [ContactUsController::class, 'deleteSelected'])->name('contact-msg.delete-selected');
    Route::post('reply/{id}', [ContactUsController::class, 'reply'])->name('contact-msg.reply');
    Route::get('/inbox', function () {
        $contactUsSubmissions = ContactUs::all();
        return view('inbox', compact('contactUsSubmissions'));
    })->name('inbox');

    // Fallback Route for undefined routes
    Route::fallback(function () {
        return response()->view('errors.404', [], 404);
    });
});



// Route::post('/api/register', [AuthApiController::class, 'register']);
// Route::post('/api/login', [AuthApiController::class, 'login']);
// Route::post('/api/logout', [AuthApiController::class, 'logout']);
// Route::post('/api/verify-otp', [AuthApiController::class, 'verifyOtp']);
// Route::post('/api/resend-otp', [AuthApiController::class, 'resendOtp']);
// Route::get('/api/otp-verify-form', [AuthApiController::class, 'showOtpVerifyForm']);
// Route::get('/api/profile', [AuthApiController::class, 'showProfile']);
// Route::post('/api/profile-image', [AuthApiController::class, 'updateProfileImage']);
// Route::get('/api/check-user-existence', [AuthApiController::class, 'checkUserExistence']);

// Route::middleware('api')->group(function () {
//     Route::get('/api/categories', [CategoryApiController::class, 'index']);
//     Route::get('/api/categories/{category}', [CategoryApiController::class, 'show']);
//     Route::get('/api/categories/{category}/products', [CategoryApiController::class, 'viewProducts']);
//     Route::get('/api/categories/{category}/subcategories', [CategoryApiController::class, 'viewSubcategories']);

//     Route::post('/api/categories/create', [CategoryApiController::class, 'store']);
//     Route::put('/api/categories/{category}', [CategoryApiController::class, 'update']);
//     Route::delete('/api/categories/{category}', [CategoryApiController::class, 'destroy']);
//     Route::post('/api/categories/restore/{id}', [CategoryApiController::class, 'restore']);
// });